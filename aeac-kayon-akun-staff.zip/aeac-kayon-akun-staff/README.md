# Akun Staff Page — Drop-In Files

## What is this?

Files for the new `/akun-staff` admin page in your Kayon Next.js project.
The folder structure inside this zip mirrors `D:\aeac-kayon\` exactly.

## How to use (3 steps)

### Step 1 — Unzip into your repo

```powershell
cd D:\aeac-kayon
git checkout main
git pull
git checkout -b feat/akun-staff
```

Then unzip this folder. You can either:
- Drag the contents of `aeac-kayon-akun-staff/` directly into `D:\aeac-kayon\` (Windows will merge folders), or
- Use 7-Zip / Windows Explorer to extract and copy

**Note:** `app/dashboard/page.tsx` will REPLACE your existing dashboard page.
That's intentional — it's the same file with one new PageLink added.

### Step 2 — Add the service-role key

Open `.env.local` in VS Code and add ONE new line:

```
SUPABASE_SERVICE_ROLE_KEY=eyJ...
```

Get the value from:
**Supabase Dashboard → Project Settings → API → service_role (secret)**

⚠️ This is the SECRET service_role key, NOT the anon key.

### Step 3 — Test locally, then deploy

```powershell
npm run dev
```

Open http://localhost:3000/akun-staff (after logging in as Emi).
You should see 5 staff under "Belum ada akun":
- Chairul, Irwan, Rheno, Rustam (technicians)
- Tiara/CIKARANG (marketing)

Click "Buat akun" on one to test. If it works:

```powershell
git add .
git commit -m "feat: /akun-staff admin page for staff onboarding"
git push -u origin feat/akun-staff
```

Then in Vercel:
1. **Settings → Environment Variables** → add `SUPABASE_SERVICE_ROLE_KEY`
   (paste same value from .env.local — apply to Production, Preview,
   and Development scopes)
2. The git push triggers a preview deploy — test it there
3. If happy, merge `feat/akun-staff` to `main`

## Database — already done

I already applied both SQL migrations to your Supabase database via MCP
during the chat. The `.sql` files in `migrations/` are just for archival
(matches your existing pattern from previous sessions). You don't need to
run them.

## Magic link — verify in Supabase

Before testing magic links, confirm in Supabase Dashboard:

1. **Authentication → Providers → Email** → enabled ✓
2. **Authentication → URL Configuration → Redirect URLs** include:
   - `https://kayon.aeac-service.id/auth/callback`
   - `http://localhost:3000/auth/callback`
3. **Authentication → Email Templates → Magic Link** → exists & looks reasonable

If anything is missing, magic link sending will silently fail (toast says
success, but no email arrives).

## Files in this zip

```
lib/
  staff-onboarding.ts             — types, helpers, color maps
  supabase/admin.ts               — service-role client (server-only)

app/
  dashboard/page.tsx              — REPLACES existing (1 new PageLink added)
  akun-staff/
    page.tsx                      — Server Component
    staff-onboarding-client.tsx   — Client Component (filter, search, buttons)
  api/akun-staff/
    create-user/route.ts          — POST endpoint to create auth user + role
    send-magic-link/route.ts      — POST endpoint to send magic link

migrations/
  aeac_kayon_get_staff_onboarding_list.sql       — already applied (archival)
  aeac_kayon_user_roles_unique_user_role.sql     — already applied (archival)
```

## Questions?

Open a new chat with Claude in your AEAC project and refer to the
session 7 continuation prompt + this work.
