/**
 * AEAC Google Apps Script — COMPLETE & UPDATED
 * Handles:
 *   1. GET  — apartments, dates, services (for booking form)
 *   2. POST — booking form submission (sends confirmation email)
 *   3. POST — report email (endpoint=report) — with inline photos
 *   4. POST — cancel email (endpoint=cancel)
 *   5. POST — invoice email (endpoint=invoice)
 *   6. POST — OTP email (action_type=send_otp) — email verification for booking form
 *   7. POST — invoice link notification (endpoint=invoice_link) — sends invoice creation link to technicians
 *
 * Changes from previous version:
 *   - sendInvoiceLinkEmail_ added (new endpoint=invoice_link)
 *   - doPost routes endpoint=invoice_link to sendInvoiceLinkEmail_
 */

// =====================================================
// == CONFIGURATION ==
// =====================================================
const SHEET_ID = "1mCg9I3RfBpnEm-Tv7xWasDLs3H8KiaIXQrkbAyZLbnI";
const BOOKING_SHEET_NAME = "BOOKINGS";

const TECHNICIANS = [
  { name: "Irwan",   email: "irwandwikarya@gmail.com" },
  { name: "Chairul", email: "kkhusnul32@yahoo.co.id" },
  { name: "Rustam",  email: "rustamathallah@gmail.com" },
  { name: "Rheno",   email: "renoharyo5@gmail.com" },
];

// =====================================================
// == SERVICE TRANSLATION MAP (Booking form) ==
// =====================================================
const SERVICE_MAP = [
  { id: "AC Split Cuci Standar (0.5–1 PK)",                  ja: "壁掛け型 簡素 (0.5-1PK)" },
  { id: "AC Split Cuci Standar (1.5–2 PK)",                  ja: "壁掛け型 簡素 (1.5-2PK)" },
  { id: "AC Split Cuci Bongkar (0.5–1 PK)",                  ja: "壁掛け型 分解 (0.5-1PK)" },
  { id: "AC Split Cuci Bongkar (1.5–2 PK)",                  ja: "壁掛け型 分解 (1.5-2PK)" },
  { id: "AC Cassette",                                        ja: "天井カセット型" },
  { id: "AC Ducting",                                         ja: "中央ダクト式" },
  { id: "Isi Ulang Freon (0.5–1 PK)",                        ja: "フロンガス補充 (0.5 PK - 1 PK)" },
  { id: "Isi Ulang Freon (1.5–2 PK)",                        ja: "フロンガス補充 (1.5 PK - 2 PK)" },
  { id: "Biaya Perbaikan",                                    ja: "修理作業代" },
  { id: "Perbaikan kebocoran air akibat kotoran",             ja: "排水詰まり（汚れ）による水漏れ" },
  { id: "Perbaikan kebocoran air akibat kondensasi",          ja: "結露（配管処理）による水漏れ" },
  { id: "Penggantian kapasitor kompresor AC",                 ja: "コンプレッサー用コンデンサー交換" },
  { id: "Perbaikan kebocoran indoor + isolasi Armaflex",      ja: "室内機の水漏れ修理（Armaflex 断熱材追加）" },
  { id: "Vakum drainase sumbat jalur",                        ja: "ドレン配管詰まり除去（バキューム作業）" },
];

// =====================================================
// == REPORT EMAIL TRANSLATION MAPS ==
// =====================================================
const PENGERJAAN_MAP = [
  { id: "General Cleaning",                                    ja: "一般クリーニング" },
  { id: "Isi Ulang Gas Freon 0.5-1 PK",                       ja: "フロンガス補充 0.5-1 PK" },
  { id: "Isi Ulang Gas Freon 1.5-2 PK",                       ja: "フロンガス補充 1.5-2 PK" },
  { id: "Perbaikan kebocoran air akibat kotoran",              ja: "排水詰まりによる水漏れ修理" },
  { id: "Perbaikan kebocoran air akibat kondensasi",           ja: "結露による水漏れ修理" },
  { id: "Penggantian kapasitor kompresor AC",                  ja: "コンプレッサーコンデンサー交換" },
  { id: "Perbaikan kebocoran indoor + isolasi Armaflex",       ja: "室内機水漏れ修理 + Armaflex断熱" },
  { id: "Vakum drainase sumbat jalur",                         ja: "ドレン詰まり真空引き" },
  { id: "Biaya Perbaikan",                                     ja: "修理作業代" },
];
const KONDISI_MAP = [
  { id: "Tidak ditemukan masalah",           ja: "異常なし" },
  { id: "Filter AC sangat kotor",            ja: "フィルター汚れ" },
  { id: "Blower indoor berdebu",             ja: "ブロワー埃付着" },
  { id: "Outdoor unit berisik",              ja: "室外機騒音" },
  { id: "Freon mulai melemah",               ja: "冷媒圧力低下" },
  { id: "Ada tetesan air dari indoor unit",  ja: "室内機水漏れ" },
  { id: "AC tidak dingin",                   ja: "冷却不良" },
  { id: "Suara AC terlalu berisik",          ja: "異音発生" },
  { id: "Remote tidak berfungsi",            ja: "リモコン不良" },
];
const TINDAKAN_MAP = [
  { id: "Cuci filter & blower indoor",               ja: "フィルター・室内機ブロワー洗浄" },
  { id: "Tambah freon",                              ja: "冷媒補充" },
  { id: "Bersihkan outdoor unit",                    ja: "室外機清掃" },
  { id: "Periksa kebocoran freon",                   ja: "冷媒漏れ確認" },
  { id: "Atur ulang remote / setting AC",            ja: "リモコン設定・ACリセット" },
  { id: "Cek kelistrikan (MCB / kabel)",             ja: "電気系統チェック（MCB・ケーブル）" },
  { id: "Ganti komponen kecil (baut, mur, dsb.)",    ja: "小部品交換（ボルト、ナットなど）" },
  { id: "Hanya inspeksi, tidak ada tindakan",        ja: "点検のみ、作業なし" },
];
const REKOMENDASI_MAP = [
  { id: "Tidak ditemukan masalah",           ja: "異常なし" },
  { id: "Filter AC sangat kotor",            ja: "フィルター汚れ" },
  { id: "Blower indoor berdebu",             ja: "ブロワー埃付着" },
  { id: "Outdoor unit berisik",              ja: "室外機騒音" },
  { id: "Freon mulai melemah",               ja: "冷媒圧力低下" },
  { id: "Ada tetesan air dari indoor unit",  ja: "室内機水漏れ" },
  { id: "AC tidak dingin",                   ja: "冷却不良" },
  { id: "Suara AC terlalu berisik",          ja: "異音発生" },
  { id: "Remote tidak berfungsi",            ja: "リモコン不良" },
];
const PERBAIKAN_MAP = [
  { id: "Isi Ulang Gas Freon (0.5 PK - 1 PK)",          ja: "フロンガス補充 (0.5PK - 1PK)" },
  { id: "Isi Ulang Gas Freon (1.5 PK - 2 PK)",          ja: "フロンガス補充 (1.5PK - 2PK)" },
  { id: "Biaya Perbaikan",                               ja: "修理作業代" },
  { id: "Perbaikan kebocoran air akibat kotoran",        ja: "排水詰まりによる水漏れ修理" },
  { id: "Perbaikan kebocoran air akibat kondensasi",     ja: "結露による水漏れ修理" },
  { id: "Penggantian kapasitor kompresor AC",            ja: "コンプレッサーコンデンサー交換" },
  { id: "Perbaikan kebocoran indoor + isolasi Armaflex", ja: "室内機水漏れ修理 + Armaflex断熱" },
  { id: "Vakum drainase sumbat jalur",                   ja: "ドレン詰まり真空引き" },
];

const UNIT_LABELS = {
  id: {
    unit_split_standar_small:     "AC Split Cuci Standar (0.5–1 PK)",
    unit_split_standar_large:     "AC Split Cuci Standar (1.5–2 PK)",
    unit_split_semibongkar_small: "AC Split Cuci Bongkar (0.5–1 PK)",
    unit_split_semibongkar_large: "AC Split Cuci Bongkar (1.5–2 PK)",
    unit_cassette:                "AC Cassette",
    unit_ducting:                 "AC Ducting",
    unit_perbaikan:               "AC Perbaikan",
  },
  ja: {
    unit_split_standar_small:     "壁掛けスタンダード (0.5–1 PK)",
    unit_split_standar_large:     "壁掛けスタンダード (1.5–2 PK)",
    unit_split_semibongkar_small: "壁掛けセミ分解 (0.5–1 PK)",
    unit_split_semibongkar_large: "壁掛けセミ分解 (1.5–2 PK)",
    unit_cassette:                "天井カセット型",
    unit_ducting:                 "中央ダクト式",
    unit_perbaikan:               "修理台数",
  }
};

// =====================================================
// == CORE HELPERS ==
// =====================================================
function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function parseRequest_(e) {
  const params      = Object.assign({}, (e && e.parameter)  ? e.parameter  : {});
  const paramsMulti = Object.assign({}, (e && e.parameters) ? e.parameters : {});

  const ctype   = (e && e.postData && e.postData.type)     ? String(e.postData.type)     : "";
  const raw     = (e && e.postData && e.postData.contents) ? String(e.postData.contents) : "";
  const hasJson = ctype.includes("application/json");

  if (raw && (hasJson || raw.trim().startsWith("{") || raw.trim().startsWith("["))) {
    try {
      const body = JSON.parse(raw);
      if (body && typeof body === "object" && !Array.isArray(body)) {
        Object.keys(body).forEach(k => {
          const v = body[k];
          if (Array.isArray(v)) {
            paramsMulti[k] = v;
            if (v.length === 1) params[k] = v[0];
          } else if (v !== undefined && v !== null) {
            params[k] = String(v);
          }
        });
      }
    } catch (err) {
      Logger.log("parseRequest_ JSON parse failed: " + err);
    }
  }

  Object.keys(paramsMulti).forEach(k => {
    const v = paramsMulti[k];
    if (!Array.isArray(v)) paramsMulti[k] = [v];
  });

  return { params, paramsMulti };
}

function parseServiceString_(raw) {
  const s         = String(raw || "").trim();
  const qtyMatch  = s.match(/[×x](\d+)/);
  const qty       = qtyMatch ? parseInt(qtyMatch[1], 10) : 1;
  const withoutPrice = s.replace(/\s*[—\-].*$/, "").trim();
  const baseName  = withoutPrice.replace(/\s*[×x]\d+\s*/, "").trim();
  const priceMatch = s.match(/Rp\s?[\d.,]+/);
  const priceStr  = priceMatch ? priceMatch[0] : "";
  return { baseName, qty, priceStr };
}

function buildServiceColumns_(rawServices, lang) {
  const isJa = lang !== "id";
  const jpParts = [], idParts = [];
  rawServices.forEach(raw => {
    const { baseName, qty, priceStr } = parseServiceString_(raw);
    const entry      = isJa ? SERVICE_MAP.find(e => e.ja === baseName) : SERVICE_MAP.find(e => e.id === baseName);
    const jaName     = entry ? entry.ja : baseName;
    const idName     = entry ? entry.id : baseName;
    const qtyStr     = qty > 1 ? " ×" + qty : "";
    const priceAppend = priceStr ? " — " + priceStr : "";
    jpParts.push(jaName + qtyStr + priceAppend);
    idParts.push(idName + qtyStr + priceAppend);
  });
  return { services_jp: jpParts.join(" | "), services_id: idParts.join(" | ") };
}

function translateList_(items, map, toJa) {
  return (items || []).map(item => {
    const entry = toJa ? map.find(e => e.id === item) : map.find(e => e.ja === item);
    return toJa ? (entry ? entry.ja : item) : (entry ? entry.id : item);
  });
}

function buildUnitSummary_(params, lang) {
  const isJa   = lang === "ja";
  const labels = isJa ? UNIT_LABELS.ja : UNIT_LABELS.id;
  const keys   = [
    "unit_split_standar_small", "unit_split_standar_large",
    "unit_split_semibongkar_small", "unit_split_semibongkar_large",
    "unit_cassette", "unit_ducting", "unit_perbaikan"
  ];
  const rows = [];
  keys.forEach(k => {
    const val = parseInt(params[k] || 0, 10);
    if (val > 0) rows.push(labels[k] + ": " + val);
  });
  return rows;
}

function formatRp_(amount) {
  if (!amount || isNaN(amount)) return "";
  return "Rp " + parseInt(amount, 10).toLocaleString("id-ID");
}

function uniqueEmails_(arr) {
  return [...new Set((arr || []).map(x => String(x || "").trim()).filter(Boolean))];
}

function assertRecipients_(toList) {
  if (!toList || !String(toList).trim()) {
    throw new Error("Recipient list is empty. Email not sent.");
  }
}

// =====================================================
// == GET HANDLER ==
// =====================================================
function doGet(e) {
  const endpoint = (e && e.parameter && e.parameter.endpoint) ? e.parameter.endpoint : "";
  const callback  = (e && e.parameter && e.parameter.callback) ? e.parameter.callback : "";
  const lang      = (e && e.parameter && e.parameter.lang)     ? e.parameter.lang     : "ja";
  let response    = { ok: false };

  try {
    const ss = SpreadsheetApp.openById(SHEET_ID);
    if      (endpoint === "dates")      response = getDates(ss, lang);
    else if (endpoint === "services")   response = getServices(ss, lang);
    else if (endpoint === "apartments") response = getApartments(ss);
    else                                response = { ok: false, error: "Unknown endpoint" };
  } catch (err) {
    response = { ok: false, error: String(err) };
  }

  if (callback) {
    return ContentService
      .createTextOutput(callback + "(" + JSON.stringify(response) + ")")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return json_(response);
}

function getDates(ss, lang) {
  try {
    const sheet = ss.getSheetByName("SLOTS");
    if (!sheet) return { ok: false, error: "Sheet SLOTS not found" };

    const headers    = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    const headerName = lang === "id" ? "AVAILABLE_ID" : "AVAILABLE_JP";
    let columnIndex  = -1;

    for (let i = 0; i < headers.length; i++) {
      if (headers[i] === headerName) { columnIndex = i + 1; break; }
    }
    if (columnIndex === -1) return { ok: false, error: "Column '" + headerName + "' not found" };

    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { ok: true, items: [] };

    const data  = sheet.getRange(2, columnIndex, lastRow - 1, 1).getValues();
    const items = data.map(r => r[0]).filter(v => v && String(v).trim() !== "");
    return { ok: true, items };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

function getServices(ss, lang) {
  try {
    const sheet = ss.getSheetByName("PRICING");
    if (!sheet) return { ok: false, error: "Sheet PRICING not found" };

    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return { ok: true, items: [], prices: {} };

    const data = sheet.getRange("F2:G" + lastRow).getValues();
    const items = [], prices = {};

    data.forEach(row => {
      const serviceName = String(lang === "id" ? row[1] : row[0]).trim();
      if (serviceName) {
        items.push(serviceName);
        const m = serviceName.match(/Rp\s?([0-9][0-9,\.]*)/);
        if (m) {
          const price = parseInt(m[1].replace(/[,\.\s]/g, ""), 10);
          if (!isNaN(price) && price > 0) prices[serviceName] = price;
        }
      }
    });

    return { ok: true, items, prices };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

function getApartments(ss) {
  try {
    const sheet = ss.getSheetByName("VAL Apartment List");
    if (!sheet) return { ok: false, error: "Sheet VAL Apartment List not found" };

    const data  = sheet.getRange("A2:A" + sheet.getLastRow()).getValues();
    const items = data.map(r => r[0]).filter(v => v && String(v).trim() !== "");
    return { ok: true, items };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

// =====================================================
// == POST HANDLER ==
// =====================================================
function doPost(e) {
  try {
    const rawType     = (e && e.postData && e.postData.type)     ? e.postData.type     : "none";
    const rawContents = (e && e.postData && e.postData.contents) ? e.postData.contents : "";
    Logger.log("doPost rawType: " + rawType);
    Logger.log("doPost rawContents (first 500): " + rawContents.substring(0, 500));

    const { params, paramsMulti } = parseRequest_(e);
    Logger.log("doPost params keys: " + Object.keys(params).join(", "));

    // ── OTP email (action_type routing) ───────────────
    const actionType = String(params.action_type || "").trim().toLowerCase();
    if (actionType === "send_otp") {
      return sendOtpEmail_(params);
    }

    // ── Reminder runner (action_type routing) ─────────
    if (actionType === "run_reminder") {
      return runReminder_();
    }

    // ── Daily booking digest (action_type routing) ────
    if (actionType === "run_daily_digest") {
      return runDailyBookingDigest_();
    }

    const endpoint = String(params.endpoint || "").trim().toLowerCase();

    // ── Cancel email ──────────────────────────────────
    if (endpoint === "cancel") {
      sendCancelEmail_(params, paramsMulti);
      return json_({ ok: true, endpoint: "cancel" });
    }

    // ── Report email ──────────────────────────────────
    if (endpoint === "report") {
      sendReportEmail_(params, paramsMulti);
      return json_({ ok: true, endpoint: "report" });
    }

    // ── Invoice email ─────────────────────────────────
    if (endpoint === "invoice") {
      sendInvoiceEmail_(params, paramsMulti);
      return json_({ ok: true, endpoint: "invoice" });
    }

    // ── Invoice link notification (to technicians) ───
    if (endpoint === "invoice_link") {
      sendInvoiceLinkEmail_(params);
      return json_({ ok: true, endpoint: "invoice_link" });
    }

    // ── Booking confirmation email ────────────────────
    const orderId       = params.orderId       || "";
    const date          = params.date          || "";
    const nameRoma      = params.nameRoma      || "";
    const nameKanji     = params.nameKanji     || "";
    const orderedBy     = params.orderedBy     || "";
    const orderedByEmail= params.orderedByEmail|| "";
    const mobile        = params.mobile        || "";
    const email         = params.email         || "";
    const apartment     = params.apartment     || "";
    const unit          = params.unit          || "";
    const message       = params.message       || "";
    const waitName      = params.waitName      || "";
    const waitMobile    = params.waitMobile    || "";
    const totalEstimate = params.totalEstimate || "";
    const services      = (paramsMulti.services || []).map(String);

    Logger.log("Sending booking email to: " + email + " orderId: " + orderId);

    try {
      sendBookingEmail_({
        orderId, date, nameRoma, nameKanji, orderedBy, orderedByEmail,
        mobile, email, apartment, unit, message, waitName, waitMobile,
        totalEstimate, services
      });
      Logger.log("Booking email sent OK");
    } catch (emailErr) {
      Logger.log("Booking email error: " + emailErr);
    }

    return json_({ ok: true, orderId: orderId });

  } catch (err) {
    Logger.log("Error in doPost: " + String(err));
    return json_({ ok: false, error: String(err) });
  }
}

// =====================================================
// == OTP VERIFICATION EMAIL (NEW)
// =====================================================
function sendOtpEmail_(data) {
  var email   = data.email   || "";
  var otpCode = data.otp_code || "";
  var lang    = data.lang    || "id";

  if (!email || !otpCode) {
    return json_({ status: "error", message: "Missing email or otp_code" });
  }

  var subject, body;

  if (lang === "ja") {
    subject = "【AEAC】メール認証コード";
    body = '<!DOCTYPE html>'
      + '<html><head><meta charset="UTF-8"></head>'
      + '<body style="font-family:\'Noto Sans JP\',Arial,sans-serif;max-width:480px;margin:0 auto;padding:24px;color:#1f2937;">'
      + '<div style="text-align:center;margin-bottom:24px;">'
      + '<h2 style="color:#d97706;margin:0 0 8px;">AEAC Service</h2>'
      + '<p style="color:#6b7280;font-size:14px;margin:0;">メール認証コード</p>'
      + '</div>'
      + '<div style="background:#fffbeb;border:2px solid #f59e0b;border-radius:12px;padding:24px;text-align:center;margin-bottom:20px;">'
      + '<p style="margin:0 0 12px;font-size:14px;color:#4b5563;">以下のコードをフォームに入力してください：</p>'
      + '<div style="font-size:36px;font-weight:700;letter-spacing:8px;color:#111827;font-family:monospace;">' + otpCode + '</div>'
      + '</div>'
      + '<p style="font-size:13px;color:#6b7280;text-align:center;">このコードは <strong>10分間</strong> 有効です。</p>'
      + '<p style="font-size:12px;color:#9ca3af;text-align:center;margin-top:16px;">このメールに心当たりがない場合は、無視してください。</p>'
      + '</body></html>';
  } else {
    subject = "【AEAC】Kode Verifikasi Email";
    body = '<!DOCTYPE html>'
      + '<html><head><meta charset="UTF-8"></head>'
      + '<body style="font-family:Roboto,Arial,sans-serif;max-width:480px;margin:0 auto;padding:24px;color:#1f2937;">'
      + '<div style="text-align:center;margin-bottom:24px;">'
      + '<h2 style="color:#d97706;margin:0 0 8px;">AEAC Service</h2>'
      + '<p style="color:#6b7280;font-size:14px;margin:0;">Kode Verifikasi Email</p>'
      + '</div>'
      + '<div style="background:#fffbeb;border:2px solid #f59e0b;border-radius:12px;padding:24px;text-align:center;margin-bottom:20px;">'
      + '<p style="margin:0 0 12px;font-size:14px;color:#4b5563;">Masukkan kode berikut di formulir pemesanan:</p>'
      + '<div style="font-size:36px;font-weight:700;letter-spacing:8px;color:#111827;font-family:monospace;">' + otpCode + '</div>'
      + '</div>'
      + '<p style="font-size:13px;color:#6b7280;text-align:center;">Kode ini berlaku selama <strong>10 menit</strong>.</p>'
      + '<p style="font-size:12px;color:#9ca3af;text-align:center;margin-top:16px;">Jika Anda tidak merasa melakukan pemesanan, abaikan email ini.</p>'
      + '</body></html>';
  }

  try {
    GmailApp.sendEmail(email, subject, "Your verification code is: " + otpCode, {
      htmlBody: body,
      name: "AEAC Service",
      replyTo: "servisacapartemen@gmail.com"
    });

    Logger.log("OTP email sent to: " + email + ", lang: " + lang);
    return json_({ status: "ok", message: "OTP email sent" });

  } catch (err) {
    Logger.log("OTP email error: " + err);
    return json_({ status: "error", message: String(err) });
  }
}

// =====================================================
// == BOOKING CONFIRMATION EMAIL (Indonesian) ==
// =====================================================
function sendBookingEmail_(p) {
  const {
    orderId, date, nameRoma, nameKanji, orderedBy, orderedByEmail,
    mobile, email, apartment, unit, message, waitName, waitMobile,
    totalEstimate, services
  } = p;

  const techEmails = TECHNICIANS.map(t => t.email);
  const recipients = [email];
  if (orderedByEmail) recipients.push(orderedByEmail);

  const toList = uniqueEmails_([...recipients, ...techEmails]).join(",");
  assertRecipients_(toList);

  const subject      = "【AEAC】Konfirmasi Pemesanan — " + orderId;
  const greetingName = orderedBy ? orderedBy : nameRoma;

  function infoRow(label, value) {
    return '<tr>' +
      '<td style="padding:8px 12px;font-size:13px;color:#6b7280;width:150px;vertical-align:top">' + label + '</td>' +
      '<td style="padding:8px 12px;font-size:13px;font-weight:500;color:#111827">' + value + '</td>' +
    '</tr>';
  }

  const servicesHtml = services.length > 0
    ? '<ul style="margin:8px 0 0;padding-left:20px">' +
        services.map(s => '<li style="font-size:13px;color:#1f2937;padding:2px 0">' + s + '</li>').join("") +
      '</ul>'
    : '<span style="font-size:13px;color:#6b7280">—</span>';

  const orderedByRow = (orderedBy && orderedBy !== nameRoma)
    ? infoRow("Dipesan oleh", orderedBy + (orderedByEmail ? ' (' + orderedByEmail + ')' : ''))
    : "";

  const siteContactRow = waitName
    ? infoRow("Kontak di lokasi", waitName + (waitMobile ? ' — ' + waitMobile : ''))
    : "";

  const notesBlock = message
    ? '<tr><td style="padding:0 32px 20px">' +
        '<div style="background:#f0fdf4;border:1.5px solid #bbf7d0;border-radius:12px;padding:14px 16px">' +
          '<div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:6px">Catatan</div>' +
          '<p style="margin:0;font-size:13px;color:#374151;line-height:1.6">' + message + '</p>' +
        '</div>' +
      '</td></tr>'
    : "";

  const totalRow = (totalEstimate && parseInt(totalEstimate, 10) > 0)
    ? infoRow("Estimasi Total", '<strong style="color:#d97706">' + formatRp_(totalEstimate) + '</strong>')
    : "";

  const html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    '<tr><td style="height:5px;background:linear-gradient(90deg,#f59e0b,#d97706)"></td></tr>' +

    '<tr><td style="padding:28px 32px 20px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:22px;font-weight:600;color:#111827">AEAC</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">Layanan Cuci &amp; Servis AC</div>' +
    '</td></tr>' +

    '<tr><td style="padding:24px 32px 0">' +
      '<p style="font-size:14px;line-height:1.7;color:#374151;margin:0">' +
        'Kepada Yth. <strong>' + greetingName + '</strong>,<br><br>' +
        'Terima kasih telah melakukan pemesanan! Kami telah menerima permintaan layanan AC Anda. ' +
        'Tim teknisi kami akan segera menghubungi Anda untuk konfirmasi lebih lanjut.' +
      '</p>' +
    '</td></tr>' +

    '<tr><td style="padding:20px 32px">' +
      '<div style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;overflow:hidden">' +
      '<table width="100%" cellpadding="0" cellspacing="0">' +
        infoRow("Order ID",  '<span style="font-family:monospace;background:#f3f4f6;padding:2px 8px;border-radius:4px">' + orderId + '</span>') +
        infoRow("Jadwal",    date) +
        infoRow("Nama",      nameRoma + (nameKanji ? ' (' + nameKanji + ')' : '')) +
        infoRow("No. HP",    mobile) +
        infoRow("Email",     email) +
        infoRow("Apartemen", apartment + " — Unit " + unit) +
        orderedByRow +
        siteContactRow +
        infoRow("Layanan",   servicesHtml) +
        totalRow +
        infoRow("Status",    '<span style="color:#16a34a;font-weight:600">✓ Diterima</span>') +
      '</table></div>' +
    '</td></tr>' +

    notesBlock +

    '<tr><td style="padding:4px 32px 28px">' +
      '<p style="font-size:13px;line-height:1.7;color:#6b7280;margin:0">' +
        'Jika ada pertanyaan atau perlu melakukan perubahan jadwal, silakan hubungi kami melalui WhatsApp. ' +
        'Harap simpan ID Pemesanan Anda sebagai referensi.<br><br>' +
        'Terima kasih telah mempercayakan perawatan AC Anda kepada AEAC.' +
      '</p>' +
    '</td></tr>' +

    '<tr><td style="padding:16px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:12px;color:#9ca3af;margin:0">AEAC — Layanan Cuci &amp; Servis AC</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>';

  GmailApp.sendEmail(toList, subject, "", {
    htmlBody: html,
    replyTo:  "servisacapartemen@gmail.com",
    name:     "AEAC",
  });

  Logger.log("Booking email sent — order: " + orderId + ", to: " + toList);
}

// =====================================================
// == CANCELLATION EMAIL ==
// =====================================================
function sendCancelEmail_(params, paramsMulti) {
  const orderId       = params.orderId       || "";
  const customerName  = params.customerName  || "";
  const customerEmail = params.customerEmail || "";
  const apartment     = params.apartment     || "";
  const unit          = params.unit          || "";
  const mobile        = params.mobile        || "";
  const scheduledDate = params.scheduledDate || "";
  const reason        = params.reason        || "";
  const bccStr        = params.bcc           || "";

  const servicesList = (paramsMulti.services || []).map(String);
  const bccList      = uniqueEmails_(bccStr.split(","));
  const techEmails   = TECHNICIANS.map(t => t.email);
  const toList       = uniqueEmails_([customerEmail, ...techEmails]).join(",");
  assertRecipients_(toList);

  const subject = "【AEAC】Order Cancellation Notice — " + orderId;

  function infoRow(label, value) {
    return '<tr>' +
      '<td style="padding:8px 12px;font-size:13px;color:#6b7280;width:140px;vertical-align:top">' + label + '</td>' +
      '<td style="padding:8px 12px;font-size:13px;font-weight:500;color:#111827">' + value + '</td>' +
    '</tr>';
  }

  const servicesHtml = servicesList.length > 0
    ? '<ul style="margin:8px 0 0;padding-left:20px">' +
        servicesList.map(s => '<li style="font-size:13px;color:#1f2937;padding:2px 0">' + s + '</li>').join("") +
      '</ul>'
    : '<span style="font-size:13px;color:#6b7280">—</span>';

  const reasonHtml = reason
    ? '<tr><td style="padding:20px 32px 0">' +
        '<div style="background:#fef2f2;border:1.5px solid #fecaca;border-radius:12px;padding:14px 16px">' +
          '<div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:6px">Alasan Pembatalan</div>' +
          '<p style="margin:0;font-size:13px;color:#374151;line-height:1.6">' + reason + '</p>' +
        '</div>' +
      '</td></tr>'
    : "";

  const html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    '<tr><td style="height:5px;background:linear-gradient(90deg,#dc2626,#b91c1c)"></td></tr>' +

    '<tr><td style="padding:28px 32px 20px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:22px;font-weight:600;color:#111827">AEAC</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">Layanan Cuci &amp; Servis AC</div>' +
    '</td></tr>' +

    '<tr><td style="padding:24px 32px 0">' +
      '<p style="font-size:14px;line-height:1.7;color:#374151;margin:0">' +
        'Kepada Yth. <strong>' + customerName + '</strong>,<br><br>' +
        'Pesanan Anda dengan ID <strong style="font-family:monospace">' + orderId + '</strong> telah resmi dibatalkan. ' +
        'Kami mohon maaf atas ketidaknyamanan ini dan berharap dapat melayani Anda kembali dalam waktu dekat.' +
      '</p>' +
    '</td></tr>' +

    '<tr><td style="padding:20px 32px">' +
      '<div style="background:#fff7ed;border:1.5px solid #fed7aa;border-radius:12px;overflow:hidden">' +
      '<table width="100%" cellpadding="0" cellspacing="0">' +
        infoRow("Order ID",  '<span style="font-family:monospace;background:#f3f4f6;padding:2px 8px;border-radius:4px">' + orderId + '</span>') +
        infoRow("Apartemen", apartment + " — Unit " + unit) +
        infoRow("Jadwal",    scheduledDate) +
        infoRow("No. HP",    mobile) +
        infoRow("Layanan",   servicesHtml) +
        infoRow("Status",    '<span style="color:#dc2626;font-weight:600">Dibatalkan</span>') +
      '</table></div>' +
    '</td></tr>' +

    reasonHtml +

    '<tr><td style="padding:20px 32px 28px">' +
      '<p style="font-size:13px;line-height:1.7;color:#6b7280;margin:0">' +
        'Jika Anda ingin menjadwalkan ulang atau memesan layanan baru, tim kami siap membantu kapan saja. ' +
        'Silakan hubungi kami melalui WhatsApp atau kunjungi halaman pemesanan kami.<br><br>' +
        'Terima kasih telah mempercayakan perawatan AC Anda kepada AEAC.' +
      '</p>' +
    '</td></tr>' +

    '<tr><td style="padding:16px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:12px;color:#9ca3af;margin:0">AEAC — Layanan Cuci &amp; Servis AC</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>';

  const mailOpts = { htmlBody: html, replyTo: "servisacapartemen@gmail.com", name: "AEAC" };
  if (bccList.length > 0) mailOpts.bcc = bccList.join(",");

  GmailApp.sendEmail(toList, subject, "", mailOpts);
  Logger.log("Cancel email sent — order: " + orderId + ", to: " + toList);
}

// =====================================================
// == REPORT EMAIL (with inline photos)
// =====================================================
function sendReportEmail_(params, paramsMulti) {
  const lang          = params.lang          || "id";
  const isJa          = lang === "ja";
  const orderId       = params.orderId       || "";
  const customerName  = params.customerName  || "";
  const customerEmail = params.customerEmail || "";
  const apartment     = params.apartment     || "";
  const unit          = params.unit          || "";
  const scheduledDate = params.scheduledDate || "";
  const jamMulai      = params.jamMulai      || "";
  const jamSelesai    = params.jamSelesai    || "";
  const technicians   = params.technicians   || "";
  const bccStr        = params.bcc           || "";

  const pengerjaanRaw  = (paramsMulti.pengerjaan  || []).map(String);
  const kondisiRaw     = (paramsMulti.kondisi     || []).map(String);
  const tindakanRaw    = (paramsMulti.tindakan    || []).map(String);
  const rekomendasiRaw = (paramsMulti.rekomendasi || []).map(String);
  const perbaikanRaw   = (paramsMulti.perbaikan   || []).map(String);
  const photoSebelum   = (paramsMulti.photoSebelum|| []).map(String);
  const photoSesudah   = (paramsMulti.photoSesudah|| []).map(String);

  const pengerjaanFinal = isJa ? translateList_(pengerjaanRaw,  PENGERJAAN_MAP,  true) : pengerjaanRaw;
  const kondisiFinal    = isJa ? translateList_(kondisiRaw,     KONDISI_MAP,     true) : kondisiRaw;
  const tindakanFinal   = isJa ? translateList_(tindakanRaw,    TINDAKAN_MAP,    true) : tindakanRaw;
  const rekoFinal       = isJa ? translateList_(rekomendasiRaw, REKOMENDASI_MAP, true) : rekomendasiRaw;
  const perbaikanFinal  = isJa ? translateList_(perbaikanRaw,   PERBAIKAN_MAP,   true) : perbaikanRaw;
  const unitRows        = buildUnitSummary_(params, lang);

  const bccList    = uniqueEmails_(bccStr.split(","));
  const techEmails = TECHNICIANS.map(t => t.email);
  const toList     = uniqueEmails_([customerEmail, ...techEmails]).join(",");
  assertRecipients_(toList);

  // ── Fetch photos and build inline image map ──────────
  const inlineImages = {};
  const cleanBefore = (photoSebelum || []).filter(u => u && String(u).trim() !== "" && String(u) !== "undefined");
  const cleanAfter  = (photoSesudah || []).filter(u => u && String(u).trim() !== "" && String(u) !== "undefined");
  const allPhotoUrls = [];

  cleanBefore.forEach((url, i) => allPhotoUrls.push({ url: url, cid: "before_" + i }));
  cleanAfter.forEach((url, i)  => allPhotoUrls.push({ url: url, cid: "after_" + i }));

  const fetchStart = new Date().getTime();
  const FETCH_TIMEOUT_MS = 25000;
  const failedUrls = [];

  allPhotoUrls.forEach(photo => {
    if (new Date().getTime() - fetchStart > FETCH_TIMEOUT_MS) {
      failedUrls.push(photo);
      return;
    }
    try {
      var response = UrlFetchApp.fetch(photo.url, { muteHttpExceptions: true, followRedirects: true, validateHttpsCertificates: false });
      if (response.getResponseCode() === 200) {
        var blob = response.getBlob();
        blob.setName(photo.cid + ".jpg");
        if (!blob.getContentType().startsWith("image/")) blob.setContentType("image/jpeg");
        inlineImages[photo.cid] = blob;
      } else {
        failedUrls.push(photo);
      }
    } catch (fetchErr) {
      Logger.log("Photo fetch error: " + fetchErr);
      failedUrls.push(photo);
    }
  });

  Logger.log("Photos: " + Object.keys(inlineImages).length + " inline, " + failedUrls.length + " failed");

  const L = isJa ? {
    subject: "【AEAC】エアコン作業完了レポート — " + orderId,
    greeting: "いつもご利用いただきありがとうございます。<br>このたびのエアコンメンテナンス作業が完了しましたので、作業レポートをお送りします。",
    orderIdLbl: "注文ID", apartmentLbl: "マンション", dateLbl: "作業日", timeLbl: "作業時間", techLbl: "担当技術者",
    workItems: "作業種別", unitCount: "台数", condition: "作業前の状態", actions: "実施した作業",
    reko: "推奨事項", repairs: "修理内容", photosBefore: "作業前写真", photosAfter: "作業後写真", noPhotos: "写真なし",
    closing: "ご不明な点やご質問がございましたら、お気軽にお問い合わせください。<br>今後ともAEACをよろしくお願いいたします。",
    footer: "AEAC — エアコンクリーニング＆修理サービス",
  } : {
    subject: "【AEAC】Laporan Pengerjaan AC — " + orderId,
    greeting: "Terima kasih telah menggunakan layanan kami.<br>Berikut adalah laporan pengerjaan AC Anda yang telah selesai dilakukan.",
    orderIdLbl: "Order ID", apartmentLbl: "Apartemen", dateLbl: "Tanggal", timeLbl: "Waktu Pengerjaan", techLbl: "Teknisi",
    workItems: "Jenis Pekerjaan", unitCount: "Jumlah Unit", condition: "Kondisi Sebelum", actions: "Tindakan yang Dilakukan",
    reko: "Rekomendasi", repairs: "Perbaikan yang Dilakukan", photosBefore: "Foto Sebelum", photosAfter: "Foto Sesudah", noPhotos: "Tidak ada foto",
    closing: "Jika ada pertanyaan atau keluhan, jangan ragu untuk menghubungi kami.<br>Terima kasih telah mempercayakan perawatan AC Anda kepada AEAC.",
    footer: "AEAC — Layanan Cuci & Servis AC",
  };

  function infoRow(label, value) {
    return '<tr><td style="padding:8px 12px;font-size:13px;color:#6b7280;width:140px;vertical-align:top">' + label + '</td>' +
      '<td style="padding:8px 12px;font-size:13px;font-weight:500;color:#111827">' + value + '</td></tr>';
  }
  function listItems(arr) {
    if (!arr || arr.length === 0) return '<li style="color:#6b7280;font-size:13px">—</li>';
    return arr.map(function(i) { return '<li style="font-size:13px;color:#1f2937;padding:2px 0">' + i + '</li>'; }).join("");
  }
  function photoGrid(urls, prefix) {
    var clean = (urls || []).filter(function(u) { return u && String(u).trim() !== "" && String(u) !== "undefined"; });
    if (clean.length === 0) return '<p style="font-size:13px;color:#6b7280;margin:8px 0">' + L.noPhotos + '</p>';
    return '<div style="margin-top:8px">' +
      clean.map(function(u, i) {
        var cid = prefix + "_" + i;
        var imgSrc = inlineImages[cid] ? "cid:" + cid : u;
        return '<a href="' + u + '" target="_blank" style="display:inline-block;margin:0 8px 8px 0">' +
          '<img src="' + imgSrc + '" width="140" height="140" style="object-fit:cover;border-radius:8px;border:1px solid #e5e7eb;display:block" />' +
        '</a>';
      }).join("") + '</div>';
  }
  function section(title, content) {
    return '<div style="margin-bottom:20px"><div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:10px">' + title + '</div>' + content + '</div>';
  }
  function optSection(title, arr) {
    return arr && arr.length > 0 ? section(title, '<ul style="margin:0;padding-left:20px">' + listItems(arr) + '</ul>') : "";
  }

  const html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +
    '<tr><td style="height:5px;background:linear-gradient(90deg,#f59e0b,#d97706)"></td></tr>' +
    '<tr><td style="padding:28px 32px 20px;border-bottom:1px solid #e5e7eb"><div style="font-size:22px;font-weight:600;color:#111827">AEAC</div><div style="font-size:13px;color:#6b7280;margin-top:4px">' + L.footer + '</div></td></tr>' +
    '<tr><td style="padding:24px 32px 0"><p style="font-size:14px;line-height:1.7;color:#374151;margin:0">' + L.greeting + '</p></td></tr>' +
    '<tr><td style="padding:20px 32px"><div style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;overflow:hidden"><table width="100%" cellpadding="0" cellspacing="0">' +
      infoRow(L.orderIdLbl, '<span style="font-family:monospace;background:#f3f4f6;padding:2px 8px;border-radius:4px">' + orderId + '</span>') +
      infoRow(L.apartmentLbl, apartment + " — Unit " + unit) +
      infoRow(L.dateLbl, scheduledDate) +
      infoRow(L.timeLbl, jamMulai + " – " + jamSelesai) +
      infoRow(L.techLbl, technicians) +
    '</table></div></td></tr>' +
    '<tr><td style="padding:0 32px 20px"><div style="border:1px solid #e5e7eb;border-radius:12px;padding:20px">' +
      section(L.workItems, '<ul style="margin:0;padding-left:20px">' + listItems(pengerjaanFinal) + '</ul>') +
      (unitRows.length > 0 ? section(L.unitCount, '<ul style="margin:0;padding-left:20px">' + listItems(unitRows) + '</ul>') : "") +
      optSection(L.condition, kondisiFinal) + optSection(L.actions, tindakanFinal) + optSection(L.reko, rekoFinal) + optSection(L.repairs, perbaikanFinal) +
    '</div></td></tr>' +
    '<tr><td style="padding:0 32px 20px"><div style="border:1px solid #e5e7eb;border-radius:12px;padding:20px">' +
      section(L.photosBefore, photoGrid(cleanBefore, "before")) +
      section(L.photosAfter, photoGrid(cleanAfter, "after")) +
    '</div></td></tr>' +
    '<tr><td style="padding:0 32px 28px"><p style="font-size:13px;line-height:1.7;color:#6b7280;margin:0">' + L.closing + '</p></td></tr>' +
    '<tr><td style="padding:16px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center"><p style="font-size:12px;color:#9ca3af;margin:0">' + L.footer + '</p></td></tr>' +
    '</table></td></tr></table></body></html>';

  const mailOpts = { htmlBody: html, replyTo: "servisacapartemen@gmail.com", name: "AEAC Technicians" };
  if (Object.keys(inlineImages).length > 0) mailOpts.inlineImages = inlineImages;
  if (bccList.length > 0) mailOpts.bcc = bccList.join(",");

  GmailApp.sendEmail(toList, L.subject, "", mailOpts);
  Logger.log("Report email sent — order: " + orderId + ", lang: " + lang + ", to: " + toList + ", inlinePhotos: " + Object.keys(inlineImages).length);
}

// =====================================================
// == INVOICE LINK NOTIFICATION (sent to technicians after report)
// =====================================================
function sendInvoiceLinkEmail_(params) {
  const orderId       = params.orderId       || "";
  const customerName  = params.customerName  || "";
  const apartment     = params.apartment     || "";
  const unit          = params.unit          || "";
  const scheduledDate = params.scheduledDate || "";
  const technicians   = params.technicians   || "";
  const invoiceLink   = params.invoiceLink   || "";
  const techEmails    = params.techEmails    || ""; // comma-separated: only techs who worked
  const ccStr         = params.cc            || ""; // aeac@maisonmap.com

  if (!invoiceLink || !techEmails) {
    Logger.log("sendInvoiceLinkEmail_ skipped — missing invoiceLink or techEmails");
    return;
  }

  const toList = uniqueEmails_(techEmails.split(",")).join(",");
  const ccList = uniqueEmails_(ccStr.split(","));
  assertRecipients_(toList);

  const subject = "【AEAC】Buat Invoice — " + orderId;
  const dateStr = Utilities.formatDate(new Date(), "Asia/Jakarta", "dd MMMM yyyy");

  const html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    // Header bar
    '<tr><td style="height:5px;background:linear-gradient(90deg,#f59e0b,#d97706)"></td></tr>' +

    // Logo
    '<tr><td style="padding:28px 32px 20px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:22px;font-weight:600;color:#111827">AEAC</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">Layanan Cuci &amp; Servis AC</div>' +
    '</td></tr>' +

    // Content
    '<tr><td style="padding:24px 32px">' +
      '<p style="font-size:14px;line-height:1.7;color:#374151;margin:0 0 16px">' +
        'Laporan teknisi untuk order berikut sudah selesai. Silakan buat dan kirim invoice ke customer.' +
      '</p>' +

      '<div style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;padding:16px;margin-bottom:20px">' +
        '<table width="100%" cellpadding="0" cellspacing="0">' +
          '<tr><td style="padding:4px 0;font-size:13px;color:#6b7280;width:120px">Order ID</td>' +
            '<td style="padding:4px 0;font-size:13px;font-weight:500;color:#111827;font-family:monospace">' + orderId + '</td></tr>' +
          '<tr><td style="padding:4px 0;font-size:13px;color:#6b7280">Customer</td>' +
            '<td style="padding:4px 0;font-size:13px;font-weight:500;color:#111827">' + customerName + '</td></tr>' +
          '<tr><td style="padding:4px 0;font-size:13px;color:#6b7280">Lokasi</td>' +
            '<td style="padding:4px 0;font-size:13px;font-weight:500;color:#111827">' + apartment + ' / ' + unit + '</td></tr>' +
          '<tr><td style="padding:4px 0;font-size:13px;color:#6b7280">Tanggal Layanan</td>' +
            '<td style="padding:4px 0;font-size:13px;font-weight:500;color:#111827">' + scheduledDate + '</td></tr>' +
          '<tr><td style="padding:4px 0;font-size:13px;color:#6b7280">Teknisi</td>' +
            '<td style="padding:4px 0;font-size:13px;font-weight:500;color:#111827">' + technicians + '</td></tr>' +
        '</table>' +
      '</div>' +

      '<p style="margin:0 0 16px;text-align:center">' +
        '<a href="' + invoiceLink + '" target="_blank" style="display:inline-block;background:#d97706;color:#ffffff;text-decoration:none;font-size:15px;font-weight:600;padding:14px 32px;border-radius:10px">📄 Buat Invoice Sekarang</a>' +
      '</p>' +

      '<p style="font-size:12px;color:#6b7280;margin:0;line-height:1.5;word-break:break-all;text-align:center">' +
        'Atau salin link berikut:<br>' + invoiceLink +
      '</p>' +

      '<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;margin-top:16px">' +
        '<p style="font-size:12px;color:#065f46;margin:0;line-height:1.5">' +
          '💡 <strong>Tip:</strong> Setelah mengirim invoice, halaman akan menampilkan QR code pembayaran. ' +
          'Tunjukkan ke customer agar bisa langsung bayar di tempat.' +
        '</p>' +
      '</div>' +
    '</td></tr>' +

    // Footer
    '<tr><td style="padding:16px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:12px;color:#9ca3af;margin:0">AEAC (Apartment Express AC Service)</p>' +
      '<p style="font-size:11px;color:#c0c0c0;margin:4px 0 0">Link ini berlaku selama 7 hari &middot; ' + dateStr + '</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>';

  const mailOpts = {
    htmlBody: html,
    replyTo:  "servisacapartemen@gmail.com",
    name:     "AEAC",
  };
  if (ccList.length > 0) mailOpts.cc = ccList.join(",");

  GmailApp.sendEmail(toList, subject, "", mailOpts);
  Logger.log("Invoice link email sent — order: " + orderId + ", to: " + toList +
    (ccList.length > 0 ? ", cc: " + ccList.join(",") : ""));
}

// =====================================================
// == INVOICE EMAIL ==
// =====================================================
function sendInvoiceEmail_(params, paramsMulti) {
  const invoiceNumber = params.invoiceNumber || "";
  const orderId       = params.orderId       || "";
  const customerName  = params.customerName  || "";
  const customerEmail = params.customerEmail || ""; // comma-separated: customer + pemesan
  const apartment     = params.apartment     || "";
  const unit          = params.unit          || "";
  const scheduledDate = params.scheduledDate || "";
  const technicians   = params.technicians   || "";
  const jamMulai      = params.jamMulai      || "";
  const jamSelesai    = params.jamSelesai    || "";
  const subtotal      = parseInt(params.subtotal || 0, 10);
  const discount      = parseInt(params.discount || 0, 10);
  const total         = parseInt(params.total    || 0, 10);
  const ccStr         = params.cc            || "";
  const bccStr        = params.bcc           || "";
  const bankName      = params.bankName      || "";
  const bankAccount   = params.bankAccount   || "";
  const bankHolder    = params.bankHolder    || "";
  const receiptWa     = params.receiptWa     || "";
  const xenditPaymentUrl = params.xenditPaymentUrl || "";

  // lineItems comes as an array of objects via JSON
  const lineItems = (paramsMulti.lineItems || []);

  const toList  = uniqueEmails_(customerEmail.split(",")).join(",");
  const ccList  = uniqueEmails_(ccStr.split(","));
  const bccList = uniqueEmails_(bccStr.split(","));

  assertRecipients_(toList);

  const subject = "【AEAC】Invoice — " + invoiceNumber;
  const dateStr = Utilities.formatDate(new Date(), "Asia/Jakarta", "dd MMMM yyyy");
  const timeStr = (jamMulai && jamSelesai) ? jamMulai + " – " + jamSelesai : "—";

  function infoRow(label, value) {
    return '<tr>' +
      '<td style="padding:6px 12px;font-size:13px;color:#6b7280;width:140px;vertical-align:top">' + label + '</td>' +
      '<td style="padding:6px 12px;font-size:13px;font-weight:500;color:#111827">' + value + '</td>' +
    '</tr>';
  }

  // Build line items table rows
  var lineRowsHtml = "";
  if (Array.isArray(lineItems) && lineItems.length > 0) {
    lineItems.forEach(function(item) {
      var desc  = String(item.description || "");
      var qty   = parseInt(item.qty || 0, 10);
      var price = parseInt(item.unit_price || 0, 10);
      var amt   = parseInt(item.amount || 0, 10);
      lineRowsHtml += '<tr>' +
        '<td style="padding:8px 10px;font-size:13px;color:#1f2937;border-bottom:1px solid #f3f4f6">' + desc + '</td>' +
        '<td style="padding:8px 10px;font-size:13px;color:#1f2937;text-align:center;border-bottom:1px solid #f3f4f6">' + qty + '</td>' +
        '<td style="padding:8px 10px;font-size:13px;color:#1f2937;text-align:right;border-bottom:1px solid #f3f4f6">' + formatRp_(price) + '</td>' +
        '<td style="padding:8px 10px;font-size:13px;color:#1f2937;text-align:right;border-bottom:1px solid #f3f4f6">' + formatRp_(amt) + '</td>' +
      '</tr>';
    });
  }

  var discountRow = discount > 0
    ? '<tr><td colspan="3" style="padding:8px 10px;font-size:13px;text-align:right;color:#6b7280">Diskon</td>' +
      '<td style="padding:8px 10px;font-size:13px;text-align:right;color:#16a34a;font-weight:500">- ' + formatRp_(discount) + '</td></tr>'
    : '';

  const html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:600px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    // Header bar
    '<tr><td style="height:5px;background:linear-gradient(90deg,#f59e0b,#d97706)"></td></tr>' +

    // Logo
    '<tr><td style="padding:28px 32px 20px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:22px;font-weight:600;color:#111827">AEAC</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">Layanan Cuci &amp; Servis AC</div>' +
      '<div style="font-size:20px;font-weight:600;color:#d97706;margin-top:8px">INVOICE</div>' +
    '</td></tr>' +

    // Greeting
    '<tr><td style="padding:24px 32px 0">' +
      '<p style="font-size:14px;line-height:1.7;color:#374151;margin:0">' +
        'Kepada Yth. <strong>' + customerName + '</strong>,<br><br>' +
        'Terima kasih telah menggunakan layanan AEAC. Berikut adalah rincian invoice Anda.' +
      '</p>' +
    '</td></tr>' +

    // Invoice details
    '<tr><td style="padding:20px 32px">' +
      '<div style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;overflow:hidden">' +
      '<table width="100%" cellpadding="0" cellspacing="0">' +
        infoRow("Nomor Invoice", '<strong>' + invoiceNumber + '</strong>') +
        infoRow("Order ID",      '<span style="font-family:monospace;background:#f3f4f6;padding:2px 8px;border-radius:4px">' + orderId + '</span>') +
        infoRow("Tanggal Layanan", scheduledDate) +
        infoRow("Lokasi",         apartment + " / " + unit) +
        infoRow("Teknisi",        technicians) +
        infoRow("Waktu",          timeStr) +
      '</table></div>' +
    '</td></tr>' +

    // Line items table
    '<tr><td style="padding:0 32px 20px">' +
      '<table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e5e7eb;border-radius:12px;overflow:hidden">' +
        '<thead><tr style="background:#f9fafb">' +
          '<th style="padding:10px;font-size:11px;font-weight:600;color:#6b7280;text-align:left;text-transform:uppercase;letter-spacing:0.5px">Deskripsi</th>' +
          '<th style="padding:10px;font-size:11px;font-weight:600;color:#6b7280;text-align:center;text-transform:uppercase;letter-spacing:0.5px;width:50px">Qty</th>' +
          '<th style="padding:10px;font-size:11px;font-weight:600;color:#6b7280;text-align:right;text-transform:uppercase;letter-spacing:0.5px;width:110px">Harga</th>' +
          '<th style="padding:10px;font-size:11px;font-weight:600;color:#6b7280;text-align:right;text-transform:uppercase;letter-spacing:0.5px;width:110px">Jumlah</th>' +
        '</tr></thead>' +
        '<tbody>' +
          lineRowsHtml +
          '<tr style="border-top:1px solid #e5e7eb"><td colspan="3" style="padding:8px 10px;font-size:13px;text-align:right;color:#6b7280">Subtotal</td>' +
            '<td style="padding:8px 10px;font-size:13px;text-align:right;font-weight:500">' + formatRp_(subtotal) + '</td></tr>' +
          discountRow +
          '<tr style="background:#fffbeb"><td colspan="3" style="padding:12px 10px;font-size:14px;font-weight:600;text-align:right;color:#111827">Total</td>' +
            '<td style="padding:12px 10px;font-size:14px;font-weight:700;text-align:right;color:#d97706">' + formatRp_(total) + '</td></tr>' +
        '</tbody>' +
      '</table>' +
    '</td></tr>' +

    // Payment info
    '<tr><td style="padding:0 32px 20px">' +
      '<div style="background:#f0fdf4;border:1.5px solid #bbf7d0;border-radius:12px;padding:16px">' +
        '<div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:0.8px;margin-bottom:10px">Informasi Pembayaran</div>' +
        '<p style="font-size:13px;color:#374151;margin:0 0 6px;line-height:1.5">Jatuh tempo: <strong style="color:#d97706">Hari yang sama</strong></p>' +
        (xenditPaymentUrl
          ? '<div style="margin:0 0 14px">' +
              '<p style="font-size:13px;color:#374151;margin:0 0 8px;line-height:1.5">Bayar Online:<br>Silakan lakukan pembayaran melalui link berikut.</p>' +
              '<p style="margin:0"><a href="' + xenditPaymentUrl + '" target="_blank" style="display:inline-block;background:#d97706;color:#ffffff;text-decoration:none;font-size:13px;font-weight:600;padding:10px 16px;border-radius:8px">Bayar Sekarang</a></p>' +
              '<p style="font-size:12px;color:#6b7280;margin:8px 0 0;line-height:1.5;word-break:break-all">' + xenditPaymentUrl + '</p>' +
            '</div>'
          : '') +

      '</div>' +
    '</td></tr>' +

    // Closing
    '<tr><td style="padding:0 32px 28px">' +
      '<p style="font-size:13px;line-height:1.7;color:#6b7280;margin:0">' +
        'Jika ada pertanyaan mengenai invoice ini, jangan ragu untuk menghubungi kami.<br>' +
        'Terima kasih telah mempercayakan perawatan AC Anda kepada AEAC.' +
      '</p>' +
    '</td></tr>' +

    // Footer
    '<tr><td style="padding:16px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:12px;color:#9ca3af;margin:0">AEAC (Apartment Express AC Service) · WhatsApp: +62 815-3280-1400 · Email: servisACapartemen@gmail.com</p>' +
      '<p style="font-size:11px;color:#c0c0c0;margin:4px 0 0">Invoice ini dibuat otomatis pada ' + dateStr + '</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>';

  // Build mail options
  const mailOpts = {
    htmlBody: html,
    replyTo:  "servisacapartemen@gmail.com",
    name:     "AEAC",
  };
  if (ccList.length > 0)  mailOpts.cc  = ccList.join(",");
  if (bccList.length > 0) mailOpts.bcc = bccList.join(",");

  GmailApp.sendEmail(toList, subject, "", mailOpts);
  Logger.log("Invoice email sent — invoice: " + invoiceNumber + ", to: " + toList +
    (ccList.length > 0 ? ", cc: " + ccList.join(",") : "") +
    (bccList.length > 0 ? ", bcc: " + bccList.join(",") : ""));
}

// =====================================================
// == TEST FUNCTIONS (run manually from GAS editor) ==
// =====================================================
function testBookingEmail() {
  sendBookingEmail_({
    orderId:        "aeac-20260223-001-testunit",
    date:           "2026-02-28 (Sabtu) Pagi",
    nameRoma:       "Test Customer",
    nameKanji:      "",
    orderedBy:      "",
    orderedByEmail: "",
    mobile:         "08123456789",
    email:          "servisacapartemen@gmail.com",
    apartment:      "Apartemen Test",
    unit:           "12A",
    message:        "Ini adalah test email konfirmasi pemesanan.",
    waitName:       "Budi",
    waitMobile:     "08198765432",
    totalEstimate:  "350000",
    services: [
      "AC Split Cuci Standar (0.5–1 PK) ×2 — Rp 180.000",
      "Isi Ulang Freon (0.5–1 PK) — Rp 350.000"
    ]
  });
  Logger.log("testBookingEmail sent!");
}

function testCancelEmail() {
  sendCancelEmail_(
    {
      orderId:       "aeac-20260223-001-testunit",
      customerName:  "Test Customer",
      customerEmail: "servisacapartemen@gmail.com",
      apartment:     "Apartemen Test",
      unit:          "12A",
      mobile:        "08123456789",
      scheduledDate: "2026-02-28 (Sabtu) Pagi",
      reason:        "Pelanggan tidak tersedia pada tanggal tersebut.",
      bcc:           "",
    },
    { services: ["AC Split Cuci Standar (0.5–1 PK) ×2 — Rp 180.000"] }
  );
  Logger.log("testCancelEmail sent!");
}

function testReportEmail() {
  sendReportEmail_(
    {
      lang:          "id",
      orderId:       "aeac-20260223-001-testunit",
      customerName:  "Test Customer",
      customerEmail: "servisacapartemen@gmail.com",
      apartment:     "Apartemen Test",
      unit:          "12A",
      scheduledDate: "2026-02-28",
      jamMulai:      "09:00",
      jamSelesai:    "11:00",
      technicians:   "Irwan, Rustam",
      bcc:           "",
      unit_split_standar_small: 2,
      unit_split_standar_large: 1,
    },
    {
      pengerjaan:   ["General Cleaning", "Biaya Perbaikan"],
      kondisi:      ["Filter AC sangat kotor", "Blower indoor berdebu"],
      tindakan:     ["Cuci filter & blower indoor"],
      rekomendasi:  ["Freon mulai melemah"],
      perbaikan:    [],
      photoSebelum: [],
      photoSesudah: [],
    }
  );
  Logger.log("testReportEmail sent!");
}

function testInvoiceEmail() {
  sendInvoiceEmail_(
    {
      invoiceNumber: "INV-20260226-001-TEST",
      orderId:       "aeac-20260226-001-test",
      customerName:  "Test Customer",
      customerEmail: "servisacapartemen@gmail.com",
      apartment:     "Apartemen Test",
      unit:          "12A",
      scheduledDate: "2026-02-26",
      technicians:   "Irwan, Rustam",
      jamMulai:      "09:00",
      jamSelesai:    "11:00",
      subtotal:      "270000",
      discount:      "0",
      total:         "270000",
      cc:            "servisacapartemen@gmail.com",
      bcc:           "",
      bankName:      "BCA (KCU Kebayoran Baru)",
      bankAccount:   "0700435393",
      bankHolder:    "Hafiz Fauzan",
      receiptWa:     "+62 856-8310-419",
    },
    {
      lineItems: [
        { description: "AC Split Cuci Standar (0.5–1 PK)", qty: 2, unit_price: 90000, amount: 180000 },
        { description: "AC Split Cuci Standar (1.5–2 PK)", qty: 1, unit_price: 90000, amount: 90000 },
      ]
    }
  );
  Logger.log("testInvoiceEmail sent!");
}

function testOtpEmail() {
  var result = sendOtpEmail_({
    email:    "servisacapartemen@gmail.com",
    otp_code: "123456",
    lang:     "id"
  });
  Logger.log("testOtpEmail result: " + result.getContent());
}

function testOtpEmailJa() {
  var result = sendOtpEmail_({
    email:    "servisacapartemen@gmail.com",
    otp_code: "654321",
    lang:     "ja"
  });
  Logger.log("testOtpEmailJa result: " + result.getContent());
}

// =====================================================
// =====================================================
// ==                                                 ==
// ==  AEAC 3-MONTH SERVICE REMINDER MODULE           ==
// ==  Appended by reminder rollout — April 2026      ==
// ==                                                 ==
// =====================================================
// =====================================================
//
// This module runs via:
//   pg_cron (Supabase) → pg_net → POST to this GAS webhook
//                      → doPost() routes action_type=run_reminder to runReminder_()
//
// Runs every Monday 09:00 WIB. Sends reminder emails to customers whose
// last AC cleaning was 80-100 days ago, with Japanese detection, MM staff
// routing, cooldown, dry-run mode, and heartbeat email to management.
//
// Config lives in Script Properties (Project Settings → Script Properties):
//   SUPABASE_URL        https://ehxldkjlyofhhzlxfnhf.supabase.co
//   SUPABASE_ANON_KEY   eyJhbG...  (your existing anon key)
//   REMINDER_DRY_RUN    true       (flip to "false" to go live)
//
// =====================================================

// =====================================================
// == REMINDER CONFIG (reads from Script Properties)   ==
// =====================================================
function reminderConfig_() {
  var props = PropertiesService.getScriptProperties();
  return {
    supabaseUrl:     props.getProperty("SUPABASE_URL") || "",
    supabaseAnonKey: props.getProperty("SUPABASE_ANON_KEY") || "",
    dryRun:          (props.getProperty("REMINDER_DRY_RUN") || "true").toLowerCase() === "true",
  };
}

// Constants that don't change
const REMINDER_MANAGEMENT_EMAIL = "aeac@maisonmap.com";
const REMINDER_MANAGER_BCC      = "maisonnagayama@gmail.com";
const REMINDER_DAYS_MIN = 80;
const REMINDER_DAYS_MAX = 100;
const REMINDER_COOLDOWN_DAYS = 30;

// Kayon staff booking form — target of the grouped (team) reminder buttons.
// Standalone customer reminders keep the public aeac-service.id link.
const KAYON_BOOKING_URL = "https://kayon.aeac-service.id/booking-staff";

// Service name prefixes that count as cleaning (excludes Freon/repair/drainage)
const REMINDER_CLEANING_PREFIXES = [
  "AC Split Cuci Standar",
  "AC Split Semi Bongkar",
  "AC Split Full Bongkar",
  "AC Split Cuci Bongkar",  // legacy name
  "AC Split Basic",          // legacy name
  "AC Split Deep",           // legacy name
  "AC Cassette",
  "AC Ducting",
];

// =====================================================
// == SUPABASE HELPERS (PostgREST REST API)            ==
// =====================================================
function sbGet_(path) {
  var cfg = reminderConfig_();
  var url = cfg.supabaseUrl + path;
  var resp = UrlFetchApp.fetch(url, {
    method: "get",
    headers: {
      "apikey": cfg.supabaseAnonKey,
      "Authorization": "Bearer " + cfg.supabaseAnonKey,
      "Accept": "application/json",
    },
    muteHttpExceptions: true,
  });
  var code = resp.getResponseCode();
  if (code < 200 || code >= 300) {
    throw new Error("Supabase GET " + path + " failed: " + code + " " + resp.getContentText().substring(0, 300));
  }
  return JSON.parse(resp.getContentText() || "[]");
}

function sbPost_(path, body) {
  var cfg = reminderConfig_();
  var url = cfg.supabaseUrl + path;
  var resp = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    headers: {
      "apikey": cfg.supabaseAnonKey,
      "Authorization": "Bearer " + cfg.supabaseAnonKey,
      "Prefer": "return=representation",
    },
    payload: JSON.stringify(body),
    muteHttpExceptions: true,
  });
  var code = resp.getResponseCode();
  if (code < 200 || code >= 300) {
    throw new Error("Supabase POST " + path + " failed: " + code + " " + resp.getContentText().substring(0, 300));
  }
  return JSON.parse(resp.getContentText() || "[]");
}

// =====================================================
// == LANGUAGE DETECTION                               ==
// =====================================================
function containsJapanese_(str) {
  if (!str) return false;
  // Hiragana U+3040–U+309F, Katakana U+30A0–U+30FF, CJK U+4E00–U+9FFF
  return /[぀-ゟ゠-ヿ一-鿿]/.test(str);
}

function detectLang_(nameRoma, nameKanji) {
  if (containsJapanese_(nameRoma) || containsJapanese_(nameKanji)) return "ja";
  return "id";
}

// =====================================================
// == MM STAFF LOOKUP (cached per run)                 ==
// =====================================================
var _mmStaffCache = null;

function loadMMStaffCache_() {
  if (_mmStaffCache) return _mmStaffCache;
  try {
    var rows = sbPost_("/rest/v1/rpc/get_mm_staff_emails", {});
    var marketing = [];
    var tro = [];
    var supervisors = [];
    (rows || []).forEach(function (r) {
      var email = (r.email || "").toLowerCase().trim();
      if (!email) return;
      if (r.role === "marketing")  marketing.push({ id: r.id, email: email, partner_tro_id: r.partner_tro_id });
      if (r.role === "tro")        tro.push({ id: r.id, email: email, partner_marketing_id: r.partner_marketing_id });
      if (r.role === "supervisor") supervisors.push({ id: r.id, email: email, active: r.active });
    });
    _mmStaffCache = { marketing: marketing, tro: tro, supervisors: supervisors };
  } catch (err) {
    Logger.log("loadMMStaffCache_ error: " + err);
    _mmStaffCache = { marketing: [], tro: [], supervisors: [] };
  }
  return _mmStaffCache;
}

function findMMStaffByEmail_(email) {
  if (!email) return null;
  var e = email.toLowerCase().trim();
  var cache = loadMMStaffCache_();
  for (var i = 0; i < cache.marketing.length; i++) {
    if (cache.marketing[i].email === e) return { role: "marketing", record: cache.marketing[i] };
  }
  for (var j = 0; j < cache.tro.length; j++) {
    if (cache.tro[j].email === e) return { role: "tro", record: cache.tro[j] };
  }
  for (var k = 0; k < cache.supervisors.length; k++) {
    if (cache.supervisors[k].email === e) return { role: "supervisor", record: cache.supervisors[k] };
  }
  return null;
}

function getMMPartnerEmail_(staffMatch) {
  if (!staffMatch) return null;
  var cache = loadMMStaffCache_();
  if (staffMatch.role === "marketing") {
    var tid = staffMatch.record.partner_tro_id;
    if (!tid) return null;
    for (var i = 0; i < cache.tro.length; i++) {
      if (cache.tro[i].id === tid) return cache.tro[i].email;
    }
  }
  if (staffMatch.role === "tro") {
    var mid = staffMatch.record.partner_marketing_id;
    if (!mid) return null;
    for (var j = 0; j < cache.marketing.length; j++) {
      if (cache.marketing[j].id === mid) return cache.marketing[j].email;
    }
  }
  return null;
}

function getActiveSupervisorEmails_() {
  var cache = loadMMStaffCache_();
  return cache.supervisors
    .filter(function (s) { return s.active === true; })
    .map(function (s) { return s.email; });
}

// ── MM teams (marketing + tro pair) for grouping the reminder per team ──
var _mmTeamsCache = null;

function loadMMTeamsCache_() {
  if (_mmTeamsCache) return _mmTeamsCache;
  var byCode = {};      // team_code -> team object
  var byEmail = {};     // lowercased email -> team object
  try {
    var rows = sbPost_("/rest/v1/rpc/get_mm_teams", {});
    (rows || []).forEach(function (t) {
      var team = {
        team_code: t.team_code || "",
        team_name: t.team_name || "",
        marketing_name:  t.marketing_name  || "",
        marketing_email: (t.marketing_email || "").toLowerCase().trim(),
        tro_name:  t.tro_name  || "",
        tro_email: (t.tro_email || "").toLowerCase().trim(),
      };
      if (team.team_code) byCode[team.team_code] = team;
      if (team.marketing_email) byEmail[team.marketing_email] = team;
      if (team.tro_email)       byEmail[team.tro_email]       = team;
    });
  } catch (err) {
    Logger.log("loadMMTeamsCache_ error: " + err);
  }
  _mmTeamsCache = { byCode: byCode, byEmail: byEmail };
  return _mmTeamsCache;
}

// Resolve the team for a unit via its booker or customer email. Returns team|null.
function findTeamForEmails_(orderedByEmail, custEmail) {
  var teams = loadMMTeamsCache_();
  var a = (orderedByEmail || "").toLowerCase().trim();
  var b = (custEmail || "").toLowerCase().trim();
  return (a && teams.byEmail[a]) || (b && teams.byEmail[b]) || null;
}

// Recipient label for the grouped email, e.g. "Tim DES (Desti & Cucum)".
function teamLabel_(team) {
  var names = [team.marketing_name, team.tro_name].filter(function (n) { return n; }).join(" & ");
  return "Tim " + team.team_code + (names ? " (" + names + ")" : "");
}

// =====================================================
// == SERVICE + DATE HELPERS                           ==
// =====================================================
function isCleaningService_(svcString) {
  if (!svcString) return false;
  for (var i = 0; i < REMINDER_CLEANING_PREFIXES.length; i++) {
    if (svcString.indexOf(REMINDER_CLEANING_PREFIXES[i]) === 0) return true;
  }
  return false;
}

function orderIdToDateStr_(orderId) {
  if (!orderId) return null;
  var m = /^aeac-(\d{8})-/.exec(orderId);
  if (!m) return null;
  var s = m[1];
  return s.substring(0, 4) + "-" + s.substring(4, 6) + "-" + s.substring(6, 8);
}

function daysBetween_(dateStrA, dateStrB) {
  var a = new Date(dateStrA + "T00:00:00Z");
  var b = new Date(dateStrB + "T00:00:00Z");
  return Math.floor((b - a) / (1000 * 60 * 60 * 24));
}

function todayStrUTC_() {
  var d = new Date();
  var y = d.getUTCFullYear();
  var mo = String(d.getUTCMonth() + 1);
  if (mo.length === 1) mo = "0" + mo;
  var da = String(d.getUTCDate());
  if (da.length === 1) da = "0" + da;
  return y + "-" + mo + "-" + da;
}

function fmtDateId_(ymd) {
  if (!ymd) return "";
  var parts = ymd.split("-");
  var months = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  return parseInt(parts[2], 10) + " " + months[parseInt(parts[1], 10) - 1] + " " + parts[0];
}

function fmtDateJa_(ymd) {
  if (!ymd) return "";
  var parts = ymd.split("-");
  return parts[0] + "年" + parseInt(parts[1], 10) + "月" + parseInt(parts[2], 10) + "日";
}

function dedupEmails_(arr) {
  var seen = {};
  var out = [];
  for (var i = 0; i < arr.length; i++) {
    var e = (arr[i] || "").trim();
    if (!e) continue;
    var lc = e.toLowerCase();
    if (seen[lc]) continue;
    seen[lc] = true;
    out.push(e);
  }
  return out;
}

// =====================================================
// == MAIN RUNNER                                      ==
// == Triggered by doPost when action_type=run_reminder ==
// =====================================================
function runReminder_() {
  var runStart = new Date();
  var cfg = reminderConfig_();
  var summary = {
    dryRun: cfg.dryRun,
    eligibleCount: 0,
    sentCount: 0,
    skippedCount: 0,
    errorCount: 0,
    entries: [],
    errors: [],
  };

  try {
    if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) {
      throw new Error("Missing Script Properties: SUPABASE_URL and/or SUPABASE_ANON_KEY. Go to Project Settings -> Script Properties to set them.");
    }

    _mmStaffCache = null; // reset cache per run
    _mmTeamsCache = null; // reset teams cache per run

    // ── Compute window: 80–100 days ago from today (UTC) ──
    var d1 = new Date();
    d1.setUTCDate(d1.getUTCDate() - REMINDER_DAYS_MAX);
    var winStart = d1.toISOString().substring(0, 10);
    var d2 = new Date();
    d2.setUTCDate(d2.getUTCDate() - REMINDER_DAYS_MIN);
    var winEnd = d2.toISOString().substring(0, 10);

    Logger.log("Reminder window: " + winStart + " to " + winEnd + " (dry_run=" + cfg.dryRun + ")");

    var winStartPfx = "aeac-" + winStart.replace(/-/g, "") + "-";
    var winEndPfx   = "aeac-" + winEnd.replace(/-/g, "") + "~";

    // ── Fetch completed cleaning orders in window ──
    var orders = sbGet_(
      "/rest/v1/orders" +
      "?select=order_id,services,status,customer_id,customers(id,name_roma,name_kanji,email,ordered_by_email,apartment,unit)" +
      "&status=eq.completed" +
      "&order_id=gte." + encodeURIComponent(winStartPfx) +
      "&order_id=lt." + encodeURIComponent(winEndPfx) +
      "&order=order_id.desc"
    );

    // ── Dedup by apartment+unit, keep most recent cleaning ──
    var unitMap = {};
    for (var i = 0; i < orders.length; i++) {
      var o = orders[i];
      var c = o.customers || {};
      if (!c.apartment || !c.unit) continue;

      var svcList = Array.isArray(o.services) ? o.services : [];
      var hasCleaning = false;
      for (var s = 0; s < svcList.length; s++) {
        if (isCleaningService_(svcList[s])) { hasCleaning = true; break; }
      }
      if (!hasCleaning) continue;

      var key = (c.apartment + "|" + c.unit).toLowerCase();
      if (!unitMap[key]) {
        unitMap[key] = {
          order: o,
          customer: c,
          lastServiceDate: orderIdToDateStr_(o.order_id),
          apartment: c.apartment,
          unit: c.unit,
        };
      }
    }

    var candidates = Object.keys(unitMap).map(function (k) { return unitMap[k]; });
    Logger.log("Candidate units after dedup: " + candidates.length);

    // ── Exclude units with future bookings ──
    var futureBookings = sbGet_(
      "/rest/v1/orders" +
      "?select=order_id,status,customers(apartment,unit)" +
      "&status=in.(pending,confirmed)"
    );
    var futureUnitKeys = {};
    (futureBookings || []).forEach(function (fb) {
      var cc = fb.customers || {};
      if (cc.apartment && cc.unit) {
        futureUnitKeys[(cc.apartment + "|" + cc.unit).toLowerCase()] = true;
      }
    });

    // ── Exclude units with reminder sent in last 30 days ──
    var cooldownDate = new Date();
    cooldownDate.setUTCDate(cooldownDate.getUTCDate() - REMINDER_COOLDOWN_DAYS);
    var recentReminders = sbGet_(
      "/rest/v1/reminder_logs" +
      "?select=apartment,unit,sent_at" +
      "&sent_at=gte." + encodeURIComponent(cooldownDate.toISOString()) +
      "&status=eq.sent"
    );
    var recentUnitKeys = {};
    (recentReminders || []).forEach(function (rr) {
      if (rr.apartment && rr.unit) {
        recentUnitKeys[(rr.apartment + "|" + rr.unit).toLowerCase()] = true;
      }
    });

    // ── Build final send list ──
    var sendList = [];
    for (var j = 0; j < candidates.length; j++) {
      var cand = candidates[j];
      var k2 = (cand.apartment + "|" + cand.unit).toLowerCase();
      if (futureUnitKeys[k2]) {
        Logger.log("Skip (future booking): " + cand.apartment + " / " + cand.unit);
        continue;
      }
      if (recentUnitKeys[k2]) {
        Logger.log("Skip (cooldown): " + cand.apartment + " / " + cand.unit);
        continue;
      }
      sendList.push(cand);
    }

    summary.eligibleCount = sendList.length;
    Logger.log("Eligible after filters: " + sendList.length);

    // ── Classify: standalone (per-unit, public link) vs team-grouped (kayon) ──
    // A unit is team-grouped only when it is NOT a standalone non-staff customer
    // (caseA) AND its booker/customer email belongs to an active MM team.
    var standaloneUnits = [];
    var teamGroups = {}; // team_code -> { team, units: [] }

    for (var g = 0; g < sendList.length; g++) {
      var u = sendList[g];
      var uc = u.customer || {};
      var uCustEmail = (uc.email || "").trim();
      var uOrderedBy = (uc.ordered_by_email || "").trim();
      var uCustStaff = uCustEmail ? findMMStaffByEmail_(uCustEmail) : null;
      var uCaseA = (uCustEmail && !uCustStaff); // non-staff customer with own email

      var team = uCaseA ? null : findTeamForEmails_(uOrderedBy, uCustEmail);
      if (team) {
        if (!teamGroups[team.team_code]) teamGroups[team.team_code] = { team: team, units: [] };
        teamGroups[team.team_code].units.push(u);
      } else {
        standaloneUnits.push(u);
      }
    }

    Logger.log("Standalone units: " + standaloneUnits.length +
               " | Team groups: " + Object.keys(teamGroups).length);

    // ── Process standalone units (unchanged per-unit flow, public link) ──
    for (var m = 0; m < standaloneUnits.length; m++) {
      try {
        var result = processReminderUnit_(standaloneUnits[m], cfg);
        summary.entries.push(result);
        if (result.status === "sent") summary.sentCount++;
        else if (result.status === "skipped_no_email") summary.skippedCount++;
        else if (result.status === "error") summary.errorCount++;
      } catch (errItem) {
        Logger.log("processReminderUnit_ error: " + errItem);
        summary.errorCount++;
        summary.errors.push(String(errItem));
      }
    }

    // ── Process team groups (one grouped email per team, kayon links) ──
    Object.keys(teamGroups).forEach(function (code) {
      try {
        var res = sendTeamReminder_(teamGroups[code], cfg);
        summary.entries.push(res);
        if (res.status === "sent") summary.sentCount += (res.unitCount || 0);
        else if (res.status === "error") summary.errorCount++;
      } catch (errTeam) {
        Logger.log("sendTeamReminder_ error [" + code + "]: " + errTeam);
        summary.errorCount++;
        summary.errors.push("team " + code + ": " + String(errTeam));
      }
    });

    // ── Send heartbeat / digest ──
    sendReminderHeartbeat_(summary, runStart);

  } catch (err) {
    Logger.log("runReminder_ FATAL: " + err);
    summary.errors.push("FATAL: " + String(err));
    try { sendReminderHeartbeat_(summary, runStart); }
    catch (e2) { Logger.log("Heartbeat also failed: " + e2); }
  }

  return json_({
    ok: true,
    dry_run: summary.dryRun,
    eligible: summary.eligibleCount,
    sent: summary.sentCount,
    skipped: summary.skippedCount,
    errors: summary.errorCount,
  });
}

// =====================================================
// == Process one eligible unit                        ==
// =====================================================
function processReminderUnit_(item, cfg) {
  var c = item.customer;
  var apartment = item.apartment;
  var unit = item.unit;
  var lastServiceDate = item.lastServiceDate;
  var refOrderId = item.order.order_id;
  var daysAgo = daysBetween_(lastServiceDate, todayStrUTC_());

  var nameRoma  = (c.name_roma || "").trim();
  var nameKanji = (c.name_kanji || "").trim();
  var custEmail = (c.email || "").trim();
  var orderedByEmail = (c.ordered_by_email || "").trim();

  var lang = detectLang_(nameRoma, nameKanji);

  var custStaffMatch   = custEmail ? findMMStaffByEmail_(custEmail) : null;
  var bookerStaffMatch = orderedByEmail ? findMMStaffByEmail_(orderedByEmail) : null;
  var isCustEmailStaff   = !!custStaffMatch;
  var isBookerEmailStaff = !!bookerStaffMatch;

  // ── Determine recipients ──
  var toEmail = "";
  var ccList = [];
  var bccList = [];

  var caseA = (custEmail && !isCustEmailStaff);

  if (caseA) {
    // Customer has own email, not MM staff — send to them
    toEmail = custEmail;
    if (orderedByEmail && orderedByEmail.toLowerCase() !== custEmail.toLowerCase()) {
      ccList.push(orderedByEmail);
    }
    if (bookerStaffMatch) {
      var partnerA = getMMPartnerEmail_(bookerStaffMatch);
      if (partnerA) ccList.push(partnerA);
    }
  } else {
    // Customer email missing or is MM staff — route through booker
    if (orderedByEmail) {
      toEmail = orderedByEmail;
    } else if (custEmail) {
      toEmail = custEmail;
    } else {
      return logReminderSkipped_(item, nameRoma, nameKanji, lang, isBookerEmailStaff || isCustEmailStaff, "no_email");
    }
    var staffForPartner = bookerStaffMatch || custStaffMatch;
    if (staffForPartner) {
      var partnerB = getMMPartnerEmail_(staffForPartner);
      if (partnerB && partnerB.toLowerCase() !== toEmail.toLowerCase()) ccList.push(partnerB);
    }
  }

  // BCC: active supervisors + manager + management archive
  var supEmails = getActiveSupervisorEmails_();
  for (var si = 0; si < supEmails.length; si++) bccList.push(supEmails[si]);
  bccList.push(REMINDER_MANAGER_BCC);
  bccList.push(REMINDER_MANAGEMENT_EMAIL);

  // Dedup + remove overlaps
  ccList  = dedupEmails_(ccList).filter(function (e) { return e.toLowerCase() !== toEmail.toLowerCase(); });
  bccList = dedupEmails_(bccList).filter(function (e) {
    if (e.toLowerCase() === toEmail.toLowerCase()) return false;
    for (var q = 0; q < ccList.length; q++) {
      if (ccList[q].toLowerCase() === e.toLowerCase()) return false;
    }
    return true;
  });

  var isMMStaff = isCustEmailStaff || isBookerEmailStaff;

  // ── Build subject + HTML ──
  var subject = (lang === "ja")
    ? "【AEAC】そろそろエアコンクリーニングの時期です"
    : "【AEAC】Sudah waktunya service AC lagi";
  var htmlBody = buildReminderHtml_(lang, nameRoma, apartment, unit, lastServiceDate, daysAgo);

  // ── Send (or skip in dry-run) ──
  if (cfg.dryRun) {
    Logger.log("[DRY RUN] Would send to=" + toEmail + " cc=" + ccList.join(",") + " bcc=" + bccList.join(","));
  } else {
    try {
      var options = {
        htmlBody: htmlBody,
        replyTo: "servisacapartemen@gmail.com",
        name: "AEAC",
      };
      if (ccList.length > 0)  options.cc  = ccList.join(",");
      if (bccList.length > 0) options.bcc = bccList.join(",");
      GmailApp.sendEmail(toEmail, subject, "", options);
      Logger.log("Reminder sent to=" + toEmail + " cc=" + ccList.join(",") + " bcc=" + bccList.join(","));
    } catch (sendErr) {
      Logger.log("Reminder send failed for " + toEmail + ": " + sendErr);
      return logReminderError_(item, nameRoma, nameKanji, lang, isMMStaff, toEmail, ccList, bccList, String(sendErr));
    }
  }

  // ── Log to Supabase ──
  try {
    sbPost_("/rest/v1/reminder_logs", {
      apartment: apartment,
      unit: unit,
      customer_id: c.id || null,
      reference_order_id: refOrderId,
      language: lang,
      to_email: toEmail,
      cc_emails: ccList.join(","),
      bcc_emails: bccList.join(","),
      is_mm_staff: isMMStaff,
      dry_run: cfg.dryRun,
      status: "sent",
      error_message: null,
    });
  } catch (logErr) {
    Logger.log("Failed to insert reminder_log: " + logErr);
  }

  return {
    status: "sent",
    apartment: apartment,
    unit: unit,
    nameRoma: nameRoma,
    lastServiceDate: lastServiceDate,
    daysAgo: daysAgo,
    lang: lang,
    isMMStaff: isMMStaff,
    to: toEmail,
    cc: ccList,
    bcc: bccList,
  };
}

function logReminderSkipped_(item, nameRoma, nameKanji, lang, isMMStaff, reason) {
  var c = item.customer;
  var cfg = reminderConfig_();
  try {
    sbPost_("/rest/v1/reminder_logs", {
      apartment: item.apartment,
      unit: item.unit,
      customer_id: c.id || null,
      reference_order_id: item.order.order_id,
      language: lang,
      to_email: null,
      cc_emails: null,
      bcc_emails: null,
      is_mm_staff: isMMStaff,
      dry_run: cfg.dryRun,
      status: "skipped_no_email",
      error_message: reason,
    });
  } catch (e) { Logger.log("log skip failed: " + e); }

  return {
    status: "skipped_no_email",
    apartment: item.apartment,
    unit: item.unit,
    nameRoma: nameRoma,
    lastServiceDate: item.lastServiceDate,
    lang: lang,
    reason: reason,
  };
}

function logReminderError_(item, nameRoma, nameKanji, lang, isMMStaff, toEmail, ccList, bccList, errMsg) {
  var c = item.customer;
  var cfg = reminderConfig_();
  try {
    sbPost_("/rest/v1/reminder_logs", {
      apartment: item.apartment,
      unit: item.unit,
      customer_id: c.id || null,
      reference_order_id: item.order.order_id,
      language: lang,
      to_email: toEmail,
      cc_emails: ccList.join(","),
      bcc_emails: bccList.join(","),
      is_mm_staff: isMMStaff,
      dry_run: cfg.dryRun,
      status: "error",
      error_message: errMsg,
    });
  } catch (e) { Logger.log("log error failed: " + e); }

  return {
    status: "error",
    apartment: item.apartment,
    unit: item.unit,
    nameRoma: nameRoma,
    error: errMsg,
  };
}

// =====================================================
// == REMINDER EMAIL HTML (ID or JA)                   ==
// =====================================================
function buildReminderHtml_(lang, nameRoma, apartment, unit, lastServiceDate, daysAgo) {
  var displayName = nameRoma || (lang === "ja" ? "お客様" : "Pelanggan");
  var unitLine = apartment + (unit ? " — Unit " + unit : "");
  var dateStr = (lang === "ja") ? fmtDateJa_(lastServiceDate) : fmtDateId_(lastServiceDate);

  var greeting, body, cta, footer;
  if (lang === "ja") {
    greeting = displayName + " 様へ";
    body =
      "<strong>" + unitLine + "</strong> のエアコンですが、<br>" +
      "前回のクリーニング（" + dateStr + "）から、もうすぐ <strong>3ヶ月</strong>になります。<br><br>" +
      "そろそろまたクリーニングのお時間です。";
    cta = "ご予約はこちら";
    footer = "AEAC — エアコンクリーニング＆修理サービス";
  } else {
    greeting = "Kepada " + displayName + ",";
    body =
      "Unit <strong>" + unitLine + "</strong>,<br>" +
      "sudah hampir <strong>3 bulan</strong> nih sejak cleaning terakhir (" + dateStr + ").<br><br>" +
      "Hayuk cleaning lagi yuuks~";
    cta = "Booking gampang di:";
    footer = "AEAC — Layanan Cuci &amp; Servis AC";
  }

  return (
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    '<tr><td style="height:5px;background:linear-gradient(90deg,#f59e0b,#d97706)"></td></tr>' +

    '<tr><td style="padding:28px 32px 16px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:22px;font-weight:600;color:#111827">AEAC</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">' + (lang === "ja" ? "エアコンクリーニング＆修理" : "Layanan Cuci &amp; Servis AC") + '</div>' +
    '</td></tr>' +

    '<tr><td style="padding:24px 32px 8px">' +
      '<p style="font-size:15px;font-weight:600;color:#111827;margin:0 0 14px">' + greeting + '</p>' +
      '<p style="font-size:14px;line-height:1.75;color:#374151;margin:0">' + body + '</p>' +
    '</td></tr>' +

    '<tr><td style="padding:20px 32px 8px">' +
      '<div style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;padding:16px 18px;text-align:center">' +
        '<p style="font-size:13px;color:#78350f;margin:0 0 8px">' + cta + '</p>' +
        '<a href="https://aeac-service.id" style="display:inline-block;background:#d97706;color:#ffffff;text-decoration:none;font-weight:600;padding:10px 22px;border-radius:8px;font-size:14px">aeac-service.id</a>' +
      '</div>' +
    '</td></tr>' +

    '<tr><td style="padding:12px 32px 24px">' +
      '<p style="font-size:12px;line-height:1.6;color:#9ca3af;margin:0;text-align:center">' +
        (lang === "ja" ? "ご不明な点があれば、このメールにご返信ください。" : "Ada pertanyaan? Balas saja email ini ya.") +
      '</p>' +
    '</td></tr>' +

    '<tr><td style="padding:14px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:11px;color:#9ca3af;margin:0">' + footer + '</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>'
  );
}

// =====================================================
// == GROUPED TEAM REMINDER (one email per MM team)    ==
// == Each unit row has its own Kayon booking button   ==
// =====================================================
function sendTeamReminder_(group, cfg) {
  var team = group.team;
  var units = group.units || [];
  if (units.length === 0) return { status: "skipped", team: team.team_code, unitCount: 0 };

  // Recipients: To = marketing, CC = tro (dedup if the team shares one inbox).
  var toEmail = team.marketing_email || team.tro_email;
  var ccList = [];
  if (team.tro_email && team.tro_email.toLowerCase() !== (toEmail || "").toLowerCase()) {
    ccList.push(team.tro_email);
  }

  // BCC: management archive only (session-18 trim).
  var bccList = [REMINDER_MANAGEMENT_EMAIL];
  ccList = dedupEmails_(ccList).filter(function (e) { return e.toLowerCase() !== (toEmail || "").toLowerCase(); });
  bccList = dedupEmails_(bccList).filter(function (e) {
    if (e.toLowerCase() === (toEmail || "").toLowerCase()) return false;
    for (var q = 0; q < ccList.length; q++) if (ccList[q].toLowerCase() === e.toLowerCase()) return false;
    return true;
  });

  var rows = units.map(function (u) {
    return {
      apartment: u.apartment,
      unit: u.unit,
      lastServiceDate: u.lastServiceDate,
      daysAgo: daysBetween_(u.lastServiceDate, todayStrUTC_()),
      services: Array.isArray(u.order.services) ? u.order.services : [],
      refOrderId: u.order.order_id,
    };
  });

  var subject = "【AEAC】" + units.length + " unit siap dijadwalkan cleaning ulang";
  var htmlBody = buildTeamReminderHtml_(teamLabel_(team), rows);

  if (cfg.dryRun) {
    Logger.log("[DRY RUN] Team " + team.team_code + " → to=" + toEmail +
               " cc=" + ccList.join(",") + " units=" + units.length);
  } else {
    assertRecipients_(toEmail);
    var options = { htmlBody: htmlBody, replyTo: "servisacapartemen@gmail.com", name: "AEAC" };
    if (ccList.length)  options.cc  = ccList.join(",");
    if (bccList.length) options.bcc = bccList.join(",");
    GmailApp.sendEmail(toEmail, subject, "", options);
    Logger.log("Team reminder sent: " + team.team_code + " → " + toEmail +
               " (" + units.length + " units)");
  }

  // One reminder_log per unit so the 30-day cooldown stays per-unit.
  units.forEach(function (u) {
    var c = u.customer || {};
    try {
      sbPost_("/rest/v1/reminder_logs", {
        apartment: u.apartment,
        unit: u.unit,
        customer_id: c.id || null,
        reference_order_id: u.order.order_id,
        language: "id",
        to_email: toEmail,
        cc_emails: ccList.join(","),
        bcc_emails: bccList.join(","),
        is_mm_staff: true,
        dry_run: cfg.dryRun,
        status: "sent",
        error_message: null,
      });
    } catch (logErr) {
      Logger.log("Team reminder_log insert failed (" + u.apartment + "/" + u.unit + "): " + logErr);
    }
  });

  return {
    status: "sent",
    team: team.team_code,
    to: toEmail,
    cc: ccList,
    bcc: bccList,
    unitCount: units.length,
    isMMStaff: true,
  };
}

function buildTeamReminderHtml_(teamLabelStr, rows) {
  var intro =
    "Ada <strong>" + rows.length + " unit</strong> yang sudah hampir 3 bulan sejak cleaning terakhir. " +
    "Silakan jadwalkan ulang lewat tombol di tiap unit — lokasi, unit, kontak, dan layanan sudah terisi otomatis.";

  var unitCards = rows.map(function (r) {
    var unitLine = r.apartment + (r.unit ? " — Unit " + r.unit : "");
    var dateStr = fmtDateId_(r.lastServiceDate);
    var svcStr = (r.services && r.services.length) ? r.services.join(", ") : "—";
    var bookingUrl = KAYON_BOOKING_URL + "?ref=" + encodeURIComponent(r.refOrderId);
    return (
      '<tr><td style="padding:8px 32px">' +
        '<table width="100%" cellpadding="0" cellspacing="0" style="border:1.5px solid #e5e7eb;border-radius:12px;overflow:hidden">' +
          '<tr><td style="padding:14px 16px 10px">' +
            '<div style="font-size:15px;font-weight:600;color:#111827">' + unitLine + '</div>' +
            '<div style="font-size:12px;color:#6b7280;margin-top:3px">Cleaning terakhir: ' + dateStr + ' · ' + r.daysAgo + ' hari lalu</div>' +
            '<div style="font-size:12px;color:#374151;margin-top:6px"><span style="color:#d97706;font-weight:600">Layanan terakhir:</span> ' + svcStr + '</div>' +
          '</td></tr>' +
          '<tr><td style="padding:12px 16px;background:#fffbeb;border-top:1px solid #fde68a">' +
            '<table width="100%" cellpadding="0" cellspacing="0"><tr>' +
              '<td style="font-size:11px;color:#78350f;line-height:1.4">Kontak &amp; layanan<br>sudah terisi</td>' +
              '<td align="right"><a href="' + bookingUrl + '" style="display:inline-block;background:#d97706;color:#ffffff;text-decoration:none;font-weight:600;padding:9px 18px;border-radius:8px;font-size:13px">Booking →</a></td>' +
            '</tr></table>' +
          '</td></tr>' +
        '</table>' +
      '</td></tr>'
    );
  }).join("");

  return (
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    '<tr><td style="height:5px;background:linear-gradient(90deg,#f59e0b,#d97706)"></td></tr>' +

    '<tr><td style="padding:28px 32px 16px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:22px;font-weight:600;color:#111827">AEAC</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">Layanan Cuci &amp; Servis AC</div>' +
    '</td></tr>' +

    '<tr><td style="padding:24px 32px 4px">' +
      '<p style="font-size:15px;font-weight:600;color:#111827;margin:0 0 12px">Halo ' + teamLabelStr + ',</p>' +
      '<p style="font-size:14px;line-height:1.7;color:#374151;margin:0">' + intro + '</p>' +
    '</td></tr>' +

    '<tr><td style="height:8px"></td></tr>' +
    unitCards +
    '<tr><td style="height:8px"></td></tr>' +

    '<tr><td style="padding:14px 32px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:11px;color:#9ca3af;margin:0">AEAC — Layanan Cuci &amp; Servis AC</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>'
  );
}

// =====================================================
// == HEARTBEAT / DIGEST EMAIL TO MANAGEMENT           ==
// == Sent every run, even if 0 eligible               ==
// =====================================================
function sendReminderHeartbeat_(summary, runStart) {
  var dateLabel = Utilities.formatDate(runStart, "Asia/Jakarta", "yyyy-MM-dd HH:mm");
  var modeLabel = summary.dryRun ? "[DRY RUN]" : "[LIVE]";
  var subject = "[AEAC Reminder] " + modeLabel + " — " + dateLabel + " — " +
                summary.sentCount + " sent / " + summary.eligibleCount + " eligible";

  var rows = "";
  summary.entries.forEach(function (e) {
    var statusColor = e.status === "sent" ? "#16a34a" : (e.status === "skipped_no_email" ? "#d97706" : "#dc2626");
    var ccStr = (e.cc || []).join(", ") || "—";
    var bccStr = (e.bcc || []).join(", ") || "—";
    rows +=
      '<tr>' +
        '<td style="padding:8px 10px;border-bottom:1px solid #e5e7eb;font-size:12px;color:#111827"><strong>' + (e.nameRoma || "—") + '</strong><br><span style="color:#6b7280">' + (e.apartment || "") + " / " + (e.unit || "") + '</span></td>' +
        '<td style="padding:8px 10px;border-bottom:1px solid #e5e7eb;font-size:12px;color:#374151">' + (e.lastServiceDate || "—") + '<br><span style="color:#6b7280">' + (e.daysAgo || "?") + ' hari</span></td>' +
        '<td style="padding:8px 10px;border-bottom:1px solid #e5e7eb;font-size:11px;color:#374151">' +
          '<strong>TO:</strong> ' + (e.to || "—") + '<br>' +
          '<strong>CC:</strong> ' + ccStr + '<br>' +
          '<strong>BCC:</strong> ' + bccStr +
        '</td>' +
        '<td style="padding:8px 10px;border-bottom:1px solid #e5e7eb;font-size:11px;text-align:center">' +
          (e.lang === "ja" ? "JA" : "ID") + (e.isMMStaff ? " *" : "") +
        '</td>' +
        '<td style="padding:8px 10px;border-bottom:1px solid #e5e7eb;font-size:11px;color:' + statusColor + ';font-weight:600">' + e.status + '</td>' +
      '</tr>';
  });

  var errorsBlock = "";
  if (summary.errors.length > 0) {
    errorsBlock =
      '<div style="background:#fef2f2;border:1.5px solid #fecaca;border-radius:10px;padding:12px 16px;margin:16px 0">' +
        '<p style="font-size:13px;font-weight:600;color:#991b1b;margin:0 0 6px">Errors</p>' +
        '<ul style="margin:0;padding-left:20px;font-size:12px;color:#7f1d1d">' +
          summary.errors.map(function (er) { return '<li>' + er + '</li>'; }).join("") +
        '</ul>' +
      '</div>';
  }

  var dryRunNotice = summary.dryRun
    ? '<div style="background:#fef3c7;border:1.5px solid #fcd34d;border-radius:10px;padding:12px 16px;margin:0 0 16px">' +
        '<p style="font-size:13px;color:#78350f;margin:0"><strong>DRY RUN MODE</strong> — No emails were actually sent to customers. To go live, change <code>REMINDER_DRY_RUN</code> to <code>false</code> in Project Settings → Script Properties.</p>' +
      '</div>'
    : '';

  var tableOrEmpty = (summary.entries.length === 0)
    ? '<p style="font-size:13px;color:#6b7280;padding:14px 0;text-align:center">✓ No eligible units this week. (This is normal if no one\'s cleaning was done 80–100 days ago, or all are already rebooked / recently reminded.)</p>'
    : '<table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e5e7eb;border-radius:8px;overflow:hidden">' +
        '<thead><tr style="background:#f9fafb">' +
          '<th style="padding:10px;text-align:left;font-size:11px;color:#6b7280;text-transform:uppercase">Tenant / Unit</th>' +
          '<th style="padding:10px;text-align:left;font-size:11px;color:#6b7280;text-transform:uppercase">Last Service</th>' +
          '<th style="padding:10px;text-align:left;font-size:11px;color:#6b7280;text-transform:uppercase">Recipients</th>' +
          '<th style="padding:10px;text-align:center;font-size:11px;color:#6b7280;text-transform:uppercase">Lang</th>' +
          '<th style="padding:10px;text-align:left;font-size:11px;color:#6b7280;text-transform:uppercase">Status</th>' +
        '</tr></thead><tbody>' + rows + '</tbody></table>';

  var html =
    '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:Helvetica Neue,Arial,sans-serif">' +
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 16px"><tr><td align="center">' +
    '<table width="100%" style="max-width:780px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">' +

    '<tr><td style="height:5px;background:linear-gradient(90deg,#6366f1,#4f46e5)"></td></tr>' +

    '<tr><td style="padding:24px 28px 18px;border-bottom:1px solid #e5e7eb">' +
      '<div style="font-size:20px;font-weight:600;color:#111827">AEAC Reminder — Weekly Run</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-top:4px">' + dateLabel + ' WIB · ' + modeLabel + '</div>' +
    '</td></tr>' +

    '<tr><td style="padding:20px 28px">' +
      dryRunNotice +
      '<div style="display:inline-block;background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:10px;padding:12px 18px;margin:0 0 14px">' +
        '<span style="font-size:13px;color:#1e3a8a"><strong>' + summary.eligibleCount + '</strong> eligible · ' +
        '<strong>' + summary.sentCount + '</strong> sent · ' +
        '<strong>' + summary.skippedCount + '</strong> skipped · ' +
        '<strong>' + summary.errorCount + '</strong> errors</span>' +
      '</div>' +
      errorsBlock +
      tableOrEmpty +
    '</td></tr>' +

    '<tr><td style="padding:14px 28px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center">' +
      '<p style="font-size:11px;color:#9ca3af;margin:0">AEAC weekly reminder cron — Monday 09:00 WIB</p>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>';

  try {
    GmailApp.sendEmail(REMINDER_MANAGEMENT_EMAIL, subject, "", {
      htmlBody: html,
      replyTo: "servisacapartemen@gmail.com",
      name: "AEAC",
    });
    Logger.log("Heartbeat email sent to " + REMINDER_MANAGEMENT_EMAIL);
  } catch (err) {
    Logger.log("Heartbeat email FAILED: " + err);
  }
}

// =====================================================
// == MANUAL TEST — run from Apps Script editor        ==
// =====================================================
function testRunReminder() {
  Logger.log("--- Manual test of runReminder_ ---");
  var result = runReminder_();
  Logger.log(result.getContent());
}

// =====================================================
// =====================================================
// ==                                                 ==
// ==  AEAC DAILY BOOKING DIGEST MODULE               ==
// ==  Appended — April 2026                          ==
// ==                                                 ==
// =====================================================
// =====================================================
//
// Sends a summary email every weekday at 16:30 WIB listing
// all bookings scheduled for TOMORROW (pending + confirmed,
// excludes cancelled and completed).
//
// Flow:
//   pg_cron (Mon-Fri 09:30 UTC = 16:30 WIB)
//     → trigger_aeac_daily_digest() Postgres function
//        → pg_net POST → GAS webhook (action_type=run_daily_digest)
//           → runDailyBookingDigest_() in this file
//              → queries orders for tomorrow's scheduled_date
//              → looks up MM staff matches + technician emails
//              → sends single HTML email via GmailApp
//
// NOTE: Skip-weekends is enforced in the cron schedule (1-5 = Mon-Fri).
// On weekdays with zero bookings, the email is still sent with an
// "empty" body so Emi knows the job ran.
//
// Sender uses the "aeac@maisonmap.com" Gmail alias (must be verified
// as a "Send mail as" alias on the Apps Script owner account).

const DIGEST_SENDER_ALIAS = "aeac@maisonmap.com";
const DIGEST_SENDER_NAME  = "Booking AEAC";
const DIGEST_TO           = "servisacapartemen@gmail.com";
const DIGEST_CC_MANAGERS  = [
  "maisonfauzan@gmail.com",
  "maisontaufik@gmail.com",
  "ibahmm@gmail.com",
  "maisonnagayama@gmail.com",
];

// =====================================================
// == DATE HELPERS (Jakarta / WIB, UTC+7)              ==
// =====================================================
// Note: these helpers are digest-specific (prefixed `digest`) so they
// don't collide with the reminder module's todayStrUTC_() etc.

function digestTomorrowYmdWIB_() {
  // WIB = UTC+7. Compute tomorrow's date in Jakarta time.
  var nowUtcMs = Date.now();
  var wibMs    = nowUtcMs + (7 * 60 * 60 * 1000);
  var tomorrowMs = wibMs + (24 * 60 * 60 * 1000);
  var d = new Date(tomorrowMs);
  var y  = d.getUTCFullYear();
  var mo = String(d.getUTCMonth() + 1);
  if (mo.length === 1) mo = "0" + mo;
  var da = String(d.getUTCDate());
  if (da.length === 1) da = "0" + da;
  return y + "-" + mo + "-" + da;
}

function digestFmtDateId_(ymd) {
  if (!ymd) return "";
  var parts = ymd.split("-");
  var y = parseInt(parts[0], 10);
  var m = parseInt(parts[1], 10);
  var d = parseInt(parts[2], 10);
  var months = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  var days   = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
  var dateObj = new Date(Date.UTC(y, m - 1, d));
  var dayName = days[dateObj.getUTCDay()];
  return dayName + ", " + d + " " + months[m - 1] + " " + y;
}

function digestExtractSession_(scheduledDate) {
  if (!scheduledDate) return "";
  var s = String(scheduledDate);
  if (s.indexOf(" AM") !== -1) return "AM";
  if (s.indexOf(" PM") !== -1) return "PM";
  // Booking form uses "Pagi" / "Siang" occasionally (but live data uses AM/PM).
  if (s.indexOf("Pagi")  !== -1) return "AM";
  if (s.indexOf("Siang") !== -1) return "PM";
  return "";
}

function digestEscHtml_(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function digestWaLink_(phone) {
  if (!phone) return "";
  var digits = String(phone).replace(/[^0-9]/g, "");
  if (!digits) return "";
  return "https://wa.me/" + digits;
}

// =====================================================
// == LOOKUP: MM staff map (email -> {name, role})     ==
// =====================================================
// Builds a lowercase-email keyed map from property.staff_marketing,
// property.staff_tro, property.staff_supervisors. Uses the same
// Supabase credentials as the reminder module (Script Properties).
//
// Returns an object:
//   { "erfi@maisonmap.com": { name: "Erfi", role: "marketing" }, ... }

function digestLoadMMStaffMap_() {
  var map = {};
  try {
    var marketing = sbGet_("/rest/v1/staff_marketing?select=name,email") || [];
    var tro       = sbGet_("/rest/v1/staff_tro?select=name,email")       || [];
    var supers    = sbGet_("/rest/v1/staff_supervisors?select=full_name,email&active=eq.true") || [];

    for (var i = 0; i < marketing.length; i++) {
      var em = String(marketing[i].email || "").trim().toLowerCase();
      if (em) map[em] = { name: marketing[i].name || "", role: "marketing" };
    }
    for (var j = 0; j < tro.length; j++) {
      var em2 = String(tro[j].email || "").trim().toLowerCase();
      if (em2) map[em2] = { name: tro[j].name || "", role: "tro" };
    }
    for (var k = 0; k < supers.length; k++) {
      var em3 = String(supers[k].email || "").trim().toLowerCase();
      if (em3) map[em3] = { name: supers[k].full_name || "", role: "supervisor" };
    }
  } catch (err) {
    Logger.log("digestLoadMMStaffMap_ failed (continuing without): " + err);
  }
  return map;
}

// The staff_marketing / staff_tro / staff_supervisors tables live in the
// `property` schema, which PostgREST serves at /rest/v1/ only when the schema
// is explicitly exposed. AEAC's setup does this via the property_* view
// pattern OR the Content-Profile header. To keep this module self-contained
// and not depend on property-schema REST exposure, we instead create a tiny
// RPC in the public schema that returns the combined staff rows. See the
// Supabase migration that accompanies this deploy (public.get_mm_staff_lookup).
//
// The function above uses sbGet_ with simple relative paths; if your setup
// doesn't expose the property schema via REST, those calls will 404 and the
// map stays empty (safe fallback — MM STAFF badge just won't show).
//
// Preferred path (what the accompanying migration sets up): swap the three
// sbGet_ calls above for a single RPC call:
//   var rows = sbPost_("/rest/v1/rpc/get_mm_staff_lookup", {}) || [];
// That RPC returns rows with {email, name, role}. The override is below:

function digestLoadMMStaffMapViaRpc_() {
  var map = {};
  try {
    var rows = sbPost_("/rest/v1/rpc/get_mm_staff_lookup", {}) || [];
    for (var i = 0; i < rows.length; i++) {
      var em = String(rows[i].email || "").trim().toLowerCase();
      if (!em) continue;
      map[em] = {
        name: rows[i].name || "",
        role: rows[i].role || "",
      };
    }
  } catch (err) {
    Logger.log("digestLoadMMStaffMapViaRpc_ failed (continuing without): " + err);
  }
  return map;
}

// =====================================================
// == LOOKUP: active technician emails                 ==
// =====================================================
function digestLoadTechnicianEmails_() {
  try {
    var rows = sbGet_("/rest/v1/technicians?select=email&is_active=eq.true") || [];
    var emails = [];
    for (var i = 0; i < rows.length; i++) {
      var em = String(rows[i].email || "").trim();
      if (em) emails.push(em);
    }
    return dedupEmails_(emails);
  } catch (err) {
    Logger.log("digestLoadTechnicianEmails_ failed: " + err);
    // Fallback to hardcoded list so CC never silently drops
    return TECHNICIANS.map(function (t) { return t.email; });
  }
}

// =====================================================
// == ROLE LABEL (Indonesian)                          ==
// =====================================================
function digestRoleLabelId_(role) {
  var r = String(role || "").toLowerCase();
  if (r === "marketing")  return "Marketing MM";
  if (r === "tro")        return "TRO MM";
  if (r === "supervisor") return "Supervisor MM";
  return "Staff MM";
}

// =====================================================
// == BUILD CARD HTML for one booking                  ==
// =====================================================
function digestBuildBookingCard_(order, mmStaffMap) {
  var c = order.customers || {};
  var orderId      = order.order_id || "";
  var sched        = order.scheduled_date || "";
  var services     = order.services || [];
  var notes        = order.notes || "";
  var waitName     = order.wait_name || "";
  var waitPhone    = order.wait_phone || "";

  var session      = digestExtractSession_(sched);
  var sessionHtml  = "";
  if (session === "AM") {
    sessionHtml = '<span style="background:#E6F1FB;color:#0C447C;font-size:11px;font-weight:500;padding:3px 10px;border-radius:999px;">AM</span>';
  } else if (session === "PM") {
    sessionHtml = '<span style="background:#FAEEDA;color:#633806;font-size:11px;font-weight:500;padding:3px 10px;border-radius:999px;">PM</span>';
  }

  var nameRoma       = (c.name_roma || "").trim();
  var nameKanji      = (c.name_kanji || "").trim();
  var custEmail      = (c.email || "").trim();
  var orderedByEmail = (c.ordered_by_email || "").trim();
  var custMobile     = (c.mobile || "").trim();
  var apartment      = (c.apartment || "").trim();
  var unit           = (c.unit || "").trim();

  // MM staff detection: customer email OR ordered_by_email matches
  var custLc   = custEmail.toLowerCase();
  var orderLc  = orderedByEmail.toLowerCase();
  var mmMatch  = (custLc  && mmStaffMap[custLc])  ||
                 (orderLc && mmStaffMap[orderLc]) || null;
  var mmBadge  = mmMatch
    ? '<span style="background:#EEEDFE;color:#26215C;font-size:10px;font-weight:500;padding:2px 8px;border-radius:4px;letter-spacing:0.3px;">MM STAFF</span>'
    : "";

  // Determine whether to show single "Email" row or split "Email pelanggan" + "Dipesan oleh"
  var emailsDiffer = orderedByEmail && custEmail &&
                     (orderLc !== custLc);
  var hasBookerOnly = !custEmail && orderedByEmail;

  // Name display: Roma (Kanji) if kanji is populated AND differs meaningfully
  var nameHtml = digestEscHtml_(nameRoma) || "—";
  if (nameKanji && nameKanji !== nameRoma) {
    nameHtml += ' <span style="color:#6b7280;font-weight:400;">(' + digestEscHtml_(nameKanji) + ')</span>';
  }

  // Location
  var locText = digestEscHtml_(apartment) || "—";
  if (unit) locText += " · " + digestEscHtml_(unit);

  // Phone link
  var phoneCell;
  if (custMobile) {
    var waUrl = digestWaLink_(custMobile);
    phoneCell = waUrl
      ? '<a href="' + waUrl + '" style="color:#185FA5;text-decoration:none;">' + digestEscHtml_(custMobile) + '</a>'
      : digestEscHtml_(custMobile);
  } else {
    phoneCell = '<span style="color:#9ca3af;">—</span>';
  }

  // Services list
  var servicesHtml;
  if (services && services.length > 0) {
    servicesHtml = services.map(function (s) {
      return digestEscHtml_(s);
    }).join("<br>");
  } else {
    servicesHtml = '<span style="color:#9ca3af;">—</span>';
  }

  // Build table rows
  var rows = "";

  // Phone row (always shown)
  rows += '<tr>' +
            '<td style="color:#6b7280;padding:3px 0;width:110px;vertical-align:top;font-size:13px;">Telepon</td>' +
            '<td style="padding:3px 0;font-size:13px;">' + phoneCell + '</td>' +
          '</tr>';

  // Email rows: three cases
  //   A) no orderedBy or same as customer → single "Email" row (if email exists)
  //   B) orderedBy differs from customer → "Email pelanggan" + "Dipesan oleh" rows
  //   C) customer has no email but orderedBy does → "Dipesan oleh" row only
  if (emailsDiffer) {
    // Case B
    rows += '<tr>' +
              '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Email pelanggan</td>' +
              '<td style="padding:3px 0;font-size:13px;"><a href="mailto:' + digestEscHtml_(custEmail) + '" style="color:#185FA5;text-decoration:none;">' + digestEscHtml_(custEmail) + '</a></td>' +
            '</tr>';
    // Dipesan oleh with MM role if matched
    var bookerLabel;
    var matchForOrdered = orderLc && mmStaffMap[orderLc];
    if (matchForOrdered) {
      bookerLabel = digestEscHtml_(matchForOrdered.name) + ' (' + digestRoleLabelId_(matchForOrdered.role) + ')';
    } else {
      // Fall back to name_kanji as booker-display (that's where the form stores "orderedBy")
      bookerLabel = digestEscHtml_(nameKanji || "—");
    }
    rows += '<tr>' +
              '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Dipesan oleh</td>' +
              '<td style="padding:3px 0;font-size:13px;">' + bookerLabel +
                ' — <a href="mailto:' + digestEscHtml_(orderedByEmail) + '" style="color:#185FA5;text-decoration:none;">' + digestEscHtml_(orderedByEmail) + '</a>' +
              '</td>' +
            '</tr>';
  } else if (hasBookerOnly) {
    // Case C — no customer email, only booker
    var matchForOrdered2 = orderLc && mmStaffMap[orderLc];
    var bookerLabel2;
    if (matchForOrdered2) {
      bookerLabel2 = digestEscHtml_(matchForOrdered2.name) + ' (' + digestRoleLabelId_(matchForOrdered2.role) + ')';
    } else {
      bookerLabel2 = digestEscHtml_(nameKanji || "—");
    }
    rows += '<tr>' +
              '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Dipesan oleh</td>' +
              '<td style="padding:3px 0;font-size:13px;">' + bookerLabel2 +
                ' — <a href="mailto:' + digestEscHtml_(orderedByEmail) + '" style="color:#185FA5;text-decoration:none;">' + digestEscHtml_(orderedByEmail) + '</a>' +
              '</td>' +
            '</tr>';
  } else if (custEmail) {
    // Case A — single email row
    rows += '<tr>' +
              '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Email</td>' +
              '<td style="padding:3px 0;font-size:13px;"><a href="mailto:' + digestEscHtml_(custEmail) + '" style="color:#185FA5;text-decoration:none;">' + digestEscHtml_(custEmail) + '</a></td>' +
            '</tr>';
  }

  // Services row
  rows += '<tr>' +
            '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Layanan</td>' +
            '<td style="padding:3px 0;font-size:13px;">' + servicesHtml + '</td>' +
          '</tr>';

  // Notes row
  var notesHtml = notes
    ? digestEscHtml_(notes)
    : '<span style="color:#9ca3af;">—</span>';
  rows += '<tr>' +
            '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Catatan</td>' +
            '<td style="padding:3px 0;font-size:13px;">' + notesHtml + '</td>' +
          '</tr>';

  // Site contact row (only if present)
  if (waitName || waitPhone) {
    var siteText = digestEscHtml_(waitName || "");
    if (waitPhone) {
      var siteWaUrl = digestWaLink_(waitPhone);
      var phoneDisplay = siteWaUrl
        ? '<a href="' + siteWaUrl + '" style="color:#185FA5;text-decoration:none;">' + digestEscHtml_(waitPhone) + '</a>'
        : digestEscHtml_(waitPhone);
      siteText += (siteText ? " — " : "") + phoneDisplay;
    }
    rows += '<tr>' +
              '<td style="color:#6b7280;padding:3px 0;vertical-align:top;font-size:13px;">Kontak di lokasi</td>' +
              '<td style="padding:3px 0;font-size:13px;">' + siteText + '</td>' +
            '</tr>';
  }

  // Card wrapper
  var card =
    '<div style="margin-bottom:16px;padding:14px 16px;border:1px solid #e5e7eb;border-radius:8px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">' +
        '<span style="font-family:Menlo,Monaco,Consolas,monospace;font-size:12px;color:#6b7280;">' + digestEscHtml_(orderId) + '</span>' +
        sessionHtml +
      '</div>' +
      '<div style="font-size:15px;font-weight:500;color:#111827;margin-bottom:4px;">' +
        nameHtml + (mmBadge ? ' &nbsp;' + mmBadge : '') +
      '</div>' +
      '<div style="font-size:13px;color:#6b7280;margin-bottom:10px;">' + locText + '</div>' +
      '<table style="width:100%;border-collapse:collapse;">' + rows + '</table>' +
    '</div>';

  return card;
}

// =====================================================
// == BUILD FULL EMAIL HTML                            ==
// =====================================================
function digestBuildEmailHtml_(tomorrowYmd, orders, mmStaffMap) {
  // Sort: AM first, then PM, then anything else — within each session by order_id
  function sessionRank(sd) {
    var s = digestExtractSession_(sd);
    if (s === "AM") return 0;
    if (s === "PM") return 1;
    return 2;
  }
  orders.sort(function (a, b) {
    var ra = sessionRank(a.scheduled_date);
    var rb = sessionRank(b.scheduled_date);
    if (ra !== rb) return ra - rb;
    return String(a.order_id).localeCompare(String(b.order_id));
  });

  // Counts
  var amCount = 0, pmCount = 0;
  for (var i = 0; i < orders.length; i++) {
    var s = digestExtractSession_(orders[i].scheduled_date);
    if (s === "AM") amCount++;
    else if (s === "PM") pmCount++;
  }

  var dateLabel = digestFmtDateId_(tomorrowYmd);
  var summaryLine;
  if (orders.length === 0) {
    summaryLine = "Tidak ada booking yang dijadwalkan untuk besok.";
  } else {
    var parts = [];
    parts.push(orders.length + " booking dijadwalkan");
    if (amCount > 0) parts.push(amCount + " AM");
    if (pmCount > 0) parts.push(pmCount + " PM");
    summaryLine = parts.join(" · ");
  }

  var cardsHtml = "";
  if (orders.length === 0) {
    cardsHtml =
      '<div style="padding:32px 16px;text-align:center;border:1px dashed #e5e7eb;border-radius:8px;color:#6b7280;font-size:14px;">' +
        'Tidak ada booking yang dijadwalkan untuk besok.' +
      '</div>';
  } else {
    for (var j = 0; j < orders.length; j++) {
      cardsHtml += digestBuildBookingCard_(orders[j], mmStaffMap);
    }
  }

  var html =
    '<!DOCTYPE html>' +
    '<html><head><meta charset="UTF-8"></head>' +
    '<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;color:#111827;">' +
    '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:24px 0;">' +
    '<tr><td align="center">' +
    '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;">' +

      // Header
      '<tr><td style="padding:20px 24px;border-bottom:1px solid #e5e7eb;background:#f9fafb;">' +
        '<div style="font-size:12px;color:#6b7280;margin-bottom:4px;letter-spacing:0.5px;text-transform:uppercase;">Booking AEAC</div>' +
        '<div style="font-size:18px;font-weight:500;color:#111827;">Pesanan Besok — ' + digestEscHtml_(dateLabel) + '</div>' +
        '<div style="font-size:13px;color:#6b7280;margin-top:6px;">' + digestEscHtml_(summaryLine) + '</div>' +
      '</td></tr>' +

      // Body
      '<tr><td style="padding:20px 24px;">' +
        cardsHtml +
      '</td></tr>' +

      // Footer
      '<tr><td style="padding:14px 24px;background:#f9fafb;border-top:1px solid #e5e7eb;text-align:center;">' +
        '<div style="font-size:12px;color:#6b7280;">AEAC — Layanan Cuci &amp; Servis AC</div>' +
        '<div style="font-size:11px;color:#9ca3af;margin-top:4px;">Dikirim otomatis setiap hari kerja pukul 16:30 WIB</div>' +
      '</td></tr>' +

    '</table>' +
    '</td></tr></table>' +
    '</body></html>';

  return { html: html, subject: "[AEAC] Pesanan Besok — " + dateLabel + " (" + orders.length + " booking)" };
}

// =====================================================
// == MAIN RUNNER                                      ==
// == Triggered by doPost when action_type=run_daily_digest ==
// =====================================================
function runDailyBookingDigest_() {
  var runStart = new Date();
  Logger.log("=== runDailyBookingDigest_ START " + runStart.toISOString() + " ===");

  try {
    var cfg = reminderConfig_(); // Reuses SUPABASE_URL / SUPABASE_ANON_KEY from reminder module
    if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) {
      throw new Error("Missing Script Properties: SUPABASE_URL and/or SUPABASE_ANON_KEY.");
    }

    // ── Compute tomorrow (WIB) ──
    var tomorrowYmd = digestTomorrowYmdWIB_();
    Logger.log("Tomorrow (WIB): " + tomorrowYmd);

    // ── Query Supabase for tomorrow's orders ──
    // scheduled_date format: "2026-04-21 (Selasa) AM"
    // Filter by LIKE "YYYY-MM-DD*", status in (pending, confirmed)
    var path =
      "/rest/v1/orders" +
      "?select=order_id,scheduled_date,services,status,notes,wait_name,wait_phone," +
                "customers(name_roma,name_kanji,ordered_by_email,mobile,email,apartment,unit)" +
      "&scheduled_date=like." + encodeURIComponent(tomorrowYmd + "*") +
      "&status=in.(pending,confirmed)" +
      "&order=order_id.asc";
    var orders = sbGet_(path) || [];
    Logger.log("Orders found for " + tomorrowYmd + ": " + orders.length);

    // ── Load MM staff lookup (email → name/role) ──
    var mmStaffMap = digestLoadMMStaffMapViaRpc_();

    // ── Load technician CC list ──
    var techEmails = digestLoadTechnicianEmails_();

    // ── Build email HTML + subject ──
    var built = digestBuildEmailHtml_(tomorrowYmd, orders, mmStaffMap);

    // ── Assemble CC list (managers + technicians, deduped) ──
    var ccList = dedupEmails_(DIGEST_CC_MANAGERS.concat(techEmails));

    // ── Send ──
    var options = {
      htmlBody: built.html,
      name:     DIGEST_SENDER_NAME,
      from:     DIGEST_SENDER_ALIAS, // Requires verified "Send mail as" alias
      replyTo:  DIGEST_SENDER_ALIAS,
      cc:       ccList.join(","),
    };
    GmailApp.sendEmail(DIGEST_TO, built.subject, "", options);

    Logger.log("Daily digest email sent to=" + DIGEST_TO + " cc=" + ccList.join(",") + " count=" + orders.length);

    return json_({
      ok: true,
      date: tomorrowYmd,
      count: orders.length,
      cc_count: ccList.length,
    });

  } catch (err) {
    Logger.log("runDailyBookingDigest_ FATAL: " + err);
    // Best-effort notify management so silent failures are visible
    try {
      GmailApp.sendEmail(
        "aeac@maisonmap.com",
        "[AEAC] Daily digest FAILED — " + runStart.toISOString(),
        "runDailyBookingDigest_ error: " + String(err),
        { name: DIGEST_SENDER_NAME, replyTo: DIGEST_SENDER_ALIAS }
      );
    } catch (e2) {
      Logger.log("Failure notification also failed: " + e2);
    }
    return json_({ ok: false, error: String(err) });
  }
}

// =====================================================
// == MANUAL TEST — run from Apps Script editor        ==
// =====================================================
function testRunDailyBookingDigest() {
  Logger.log("--- Manual test of runDailyBookingDigest_ ---");
  var result = runDailyBookingDigest_();
  Logger.log(result.getContent());
}
